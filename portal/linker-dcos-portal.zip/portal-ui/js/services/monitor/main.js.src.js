define(['app'], function (app) {
    'use strict';
     app.provide.factory('MonitorService', ['$http','$q',function ($http,$q) {
	    	return {
	    		getContainers : function(nginxip){
					var deferred = $q.defer();
					var url = "/monitor/containers";
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET",
						"params": {
						  "clientAddr": nginxip
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
				},
				getServices : function(nginxip){
					var deferred = $q.defer();
					var url = "/appsets?count=true&skip_group=1&skip=0&limit=0";
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET",
						"params": {
						  "clientAddr": nginxip
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
				},
				getServiceContainers : function(nginxip,groupid){
					var deferred = $q.defer();
					var url = "/monitor/service/containers";
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET",
						"params": {
						  "clientAddr": nginxip,
						  "groupid" : groupid
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
				},
               	nodeMonitor : function(ip){
					var deferred = $q.defer();
					var url = "/nodemonitoring?ip="+ip;		
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET"
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
				},
				nodeSpec : function(ip){
					var deferred = $q.defer();
					var url = "/nodespec?ip="+ip;		
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET"
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
				},
				containerMonitor : function(ip,dockername){
					var deferred = $q.defer();
					var url = "/containermonitoring?ip=" + ip + "&dockername=" + dockername;		
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET"
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
				},
				containerSpec : function(ip,dockername){
					var deferred = $q.defer();
					var url = "/containerspec?ip=" + ip + "&dockername=" + dockername;		
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET"
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
				}
	    	}
	    	
     }]);
});