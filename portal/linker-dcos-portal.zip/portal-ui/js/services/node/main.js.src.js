define(['app', '../cluster/main'], function(app) {
	'use strict';
	app.provide.factory('NodeService', ['$http', '$q', '$uibModal', 'ClusterService', function($http, $q, $uibModal, ClusterService) {
		return {
			getNodes: function(cluster_id, skip, limit) {
				var deferred = $q.defer();
				if (_.isUndefined(cluster_id)) cluster_id = "";
				if (_.isUndefined(skip)) skip = "";
				if (_.isUndefined(limit)) limit = "";
				var url = "/cluster/" + cluster_id + "/hosts?count=true&skip=" + skip + "&limit=" + limit;
				var request = {
					"url": url,
					"dataType": "json",
					"method": "GET"
				}
				$http(request).success(function(data) {
					deferred.resolve(data);
				}).error(function(error) {
					deferred.reject(error);
				});
				return deferred.promise;
			},
			createNode:function(node){
				var deferred = $q.defer();
				var url = "/cluster/" + node.clusterId + "/hosts";
				var request = {
					"url": url,
					"dataType": "json",
					"method": "POST",
					"data": angular.toJson(node)
				}
				$http(request).success(function(data) {
					deferred.resolve(data);
				}).error(function(error) {
					deferred.reject(error);
				});
				return deferred.promise;
			},
			terminateNode: function(node) {
				var deferred = $q.defer();
				var url = "/cluster/" + node.cluster_id + "/hosts";
				var request = {
					url: url,
					method: 'DELETE',
					data: {
						host_ids:node._id
					},
					headers: {
						"Content-Type": "application/json;charset=utf-8"
					}
				}
				$http(request).success(function(data) {
					deferred.resolve(data);
				}).error(function(error) {
					deferred.reject(error);
				});
				return deferred.promise;
			}
		}

	}]);
});