define(['app'], function(app) {
	'use strict';
	app.provide.factory('PlatformService', ['$http', '$q', function($http, $q) {
		return {
			createProvider: function(provider) {
				if (provider.type == "openstack"){
					delete provider.awsEc2Info
				}else{
					delete provider.openstackInfo
				}
				var deferred = $q.defer();
				var url = "/provider";
				var request = {
					"url": url,
					"dataType": "json",
					"method": "POST",
					"data": angular.toJson(provider),
				}

				$http(request).success(function(data) {
					deferred.resolve(data);
				}).error(function(error) {
					deferred.reject(error);
				});
				return deferred.promise;
			},
			getProvider: function(limit, skip, provider) {
				var deferred = $q.defer();
				var url = "/provider?count=true&skip=" + skip + "&limit=" + limit + "&user_id=" + provider;
				var request = {
					"url": url,
					"dataType": "json",
					"method": "GET"
				}

				$http(request).success(function(data) {
					deferred.resolve(data);
				}).error(function(error) {
					deferred.reject(error);
				});
				return deferred.promise;
			},
			editProvider: function(provider) {
				var deferred = $q.defer();
				if (provider.type == "openstack"){
					delete provider.awsEc2Info
				}else{
					delete provider.openstackInfo
				}
				var url = "/provider/" + provider._id;
				var request = {
					"url": url,
					"dataType": "json",
					"method": "PUT",
					"data":angular.toJson(provider)
				}
				$http(request).success(function(data) {
					deferred.resolve(data);
				}).error(function(error) {
					deferred.reject(error);
				});
				return deferred.promise;
			},
			deleteProvider: function(provider) {
				var deferred = $q.defer();
				var url = "/provider/" + provider._id;
				var request = {
					"url": url,
					"dataType": "json",
					"method": "DELETE"
				}
				$http(request).success(function(data) {
					deferred.resolve(data);
				}).error(function(error) {
					deferred.reject(error);
				});
				return deferred.promise;
			}
		}

	}]);
});