define(['app'], function (app) {
    'use strict';
     app.provide.factory('KeyPairService', ['$http','$q',function ($http,$q) {
	    	return {
                getKeyPairs : function(skip, limit){
					var deferred = $q.defer();
					var url = "/keypair?count=true&skip="+skip+"&limit="+limit;		
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET"
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
					
			    },
			    createKeyPair : function(keypair){
			    	var deferred = $q.defer();
					var url = "/keypair/create";	
					var request = {
						"url": url,
						"dataType": "json",
						"method": "POST",
						"data" : angular.toJson(keypair),
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    downloadKeyPair : function(userid){
					var deferred = $q.defer();
					var url = "/keypair/download/"+userid;		
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET"
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
					
			    },
			    uploadKeyPair : function(keypair){
			    	var deferred = $q.defer();
					var url = "/keypair/upload";	
					var request = {
						"url": url,
						"dataType": "json",
						"method": "POST",
						"data" : angular.toJson(keypair),
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    deleteKeyPair : function(keypair){
			    	var deferred = $q.defer();
					var url = "/keypair/"+keypair._id;		
					var request = {
						"url": url,
						"dataType": "json",
						"method": "DELETE"	
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    }
	    	}
	    	
     }]);
});