define(['app'], function(app) {
	'use strict';
	app.provide.factory('NetworkService', ['$http', '$q', function($http, $q) {
		return {
			getNetwork: function(clientAddr, skip, limit) {
				var deferred = $q.defer();
				var url = "/network?skip=" + skip + "&limit=" + limit;
				var request = {
					"url": url,
					"dataType": "json",
					"method": "GET",
					"params": {
						"clientAddr": clientAddr
					}
				}
				$http(request).success(function(data) {
					deferred.resolve(data);
				}).error(function(error) {
					deferred.reject(error);
				});
				return deferred.promise;
			}
		}
	}]);
});