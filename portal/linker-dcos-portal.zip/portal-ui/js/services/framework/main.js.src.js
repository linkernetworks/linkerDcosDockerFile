define(['app'], function (app) {
    'use strict';
     app.provide.factory('FrameworkService', ['$http','$q',function ($http,$q) {
	    	return {
			    get : function(clientAddr, skip, limit, type, filter){
			    	var deferred = $q.defer();
					var url = "/frameworks/" + type +"?count=true&skip="+skip+"&limit="+limit;
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET",
						"params": {
						  "clientAddr": clientAddr,
						  "framework_name":filter
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			 
			    delete : function(clientAddr, framework, type){
                    var deferred = $q.defer();
					var url = "/frameworks/"+ type + "/" + framework.name;
					var request = {
						"url": url,
						"dataType": "json",
						"method": "DELETE",
						"params": {
						  "clientAddr": clientAddr
					    }
					}
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    install : function(clientAddr, framework){
			    	var deferred = $q.defer();
					var url = "/frameworks/instances";
					var request = {
						"url": url,
						"dataType": "json",
						"method": "POST",
						"data": angular.toJson(framework),
						"params": {
						  "clientAddr": clientAddr,
						  "deploy":true
					    }
					}
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			 
				getTasks :function(clientAddr,host_ip,skip, limit){
					var deferred = $q.defer();
					var url = "/tasks?count=true&skip="+skip+"&limit="+limit+"&host_ip="+host_ip;
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET",
						"params": {
						  "clientAddr": clientAddr
					    }
					}
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
				}
	
	    	}
     }]);
});