define(['app'], function (app) {
    'use strict';
     app.provide.factory('FrameworkService', ['$http','$q',function ($http,$q) {
	    	return {
                getFrameworks : function(clientAddr){
					var deferred = $q.defer();
				
					
					return deferred.promise;
					
			    },
			    getDeployedFrameworks : function(clientAddr, skip, limit){
			    	var deferred = $q.defer();
					// var url = "/frameworks/deployed?skip="+skip+"&limit="+limit;
					// var request = {
					// 	"url": url,
					// 	"dataType": "json",
					// 	"method": "GET",
					// 	"params": {
					// 	  "clientAddr": clientAddr
					//     }
					// }
						
					// $http(request).success(function(data){
					// 	deferred.resolve(data);
					// }).error(function(error){
					// 	deferred.reject(error);
					// });
					return deferred.promise;
			    },
			    getTasks : function(clientAddr, skip, limit,filter){
			    	var deferred = $q.defer();
					
					return deferred.promise;
			    },
			    uninstallFramework : function(framework){
                    var deferred = $q.defer();
					// var url = "/frameworks/"+framework._id;
					// var request = {
					// 	"url": url,
					// 	"dataType": "json",
					// 	"method": "DELETE"
					// }
					// $http(request).success(function(data){
					// 	deferred.resolve(data);
					// }).error(function(error){
					// 	deferred.reject(error);
					// });
					return deferred.promise;
			    },
			    installFramework : function(framework){
			    	var deferred = $q.defer();
					
					return deferred.promise;
			    }


	    	}
	    	
     }]);
});