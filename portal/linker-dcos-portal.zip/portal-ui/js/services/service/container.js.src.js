define(['app'], function (app) {
    'use strict';
     app.provide.factory('ContainerService', ['$http','$q',function ($http,$q) {
	    	return {              
			    get : function(clientAddr,taskid,appsetName,componentName){
			    	var deferred = $q.defer();
					var url = "/container/"+taskid;
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET",
						"params": {
						  "clientAddr": clientAddr,
						  "appset_name":appsetName,
						  "component_name":componentName
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    restart : function(clientAddr,taskid,appsetName,componentName){
			    	var deferred = $q.defer();
					var url = "/container/"+taskid+"/restart";
					var request = {
						"url": url,
						"dataType": "json",
						"method": "PUT",
						"params": {
						  "clientAddr": clientAddr,
						  "appset_name":appsetName,
						  "component_name":componentName
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    }
			    
			  
			    


	    	}
	    	
     }]);
});