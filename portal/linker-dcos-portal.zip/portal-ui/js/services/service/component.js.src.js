define(['app'], function(app) {
    'use strict';
    app.provide.factory('ComponentService', ['$http', '$q', function($http, $q) {
        return {
            componentJSON: function() {
                return {
                    JSONTemplate: {
                        "marathon_app": {
                            "id": "",
                            "cmd": "",
                            "args": [],
                            "instances": 1,
                            "cpus": "",
                            "mem": "",
                            "dependencies": [],
                            "labels": {},
                            "container": {
                                "type": "DOCKER",
                                "docker": {
                                    "image": "",
                                    "network": "BRIDGE",
                                    "parameters":[],
                                    "portMappings": [],
                                    "privileged": true,
                                    "forcePullImage": true
                                },
                                "volumes": []
                            },
                            "env": {},
                            "constraints": []
                        }
                    },
                    portMapping: {
                        "containerPort": 0,
                        "hostPort": 0,
                        "servicePort": 0,
                        "protocol": "tcp"
                    },

                    volume: {
                        "containerPath": "",
                        "hostPath": "",
                        "mode": "RO"
                    }
                }


            },
            goNext : function(current) {
                var stepObj = {};
                switch (current) {
                    case "basic":
                        stepObj = { "previous": "basic", "current": "container", "next": "feature" };
                        break;
                    case "container":
                        stepObj = { "previous": "container", "current": "feature", "next": "relationship" };
                        break;
                    case "feature":
                        stepObj = { "previous": "feature", "current": "relationship", "next": "advanced" };
                        break;
                    case "relationship":
                        stepObj = { "previous": "relationship", "current": "advanced", "next": "" };
                        break;
                    case "advanced":
                        stepObj = { "previous": "relationship", "current": "advanced", "next": "" };
                        break;
                    default:
                        stepObj = { "previous": "", "current": "basic", "next": "container" };
                }
                return stepObj;
            },
             goPrevious : function(current) {
             	var stepObj = {};
                switch (current) {
                    case "basic":
                        stepObj = { "previous": "", "current": "basic", "next": "container" };
                        break;
                    case "container":
                        stepObj = { "previous": "", "current": "basic", "next": "container" };
                        break;
                    case "feature":
                        stepObj = { "previous": "basic", "current": "container", "next": "feature" };
                        break;
                    case "relationship":
                        stepObj = { "previous": "container", "current": "feature", "next": "relationship" };
                        break;
                    case "advanced":
                        stepObj = { "previous": "feature", "current": "relationship", "next": "advanced" };
                        break;
                    default:
                        stepObj = { "previous": "", "current": "basic", "next": "container" };
                }
                return stepObj;
            },
            setCurrent : function(current) {
                var stepObj = {};
                switch (current) {
                    case "basic":
                        stepObj = { "previous": "", "current": "basic", "next": "container" };
                        break;
                    case "container":
                        stepObj = { "previous": "basic", "current": "container", "next": "feature" };
                        break;
                    case "feature":
                        stepObj = { "previous": "container", "current": "feature", "next": "relationship" };
                        break;
                    case "relationship":
                        stepObj = { "previous": "feature", "current": "relationship", "next": "advanced" };
                        break;
                    case "advanced":
                        stepObj = { "previous": "relationship", "current": "advanced", "next": "" };
                        break;
                    default:
                        stepObj = { "previous": "", "current": "basic", "next": "container" };
                }
                return stepObj;
            },

            getDetail: function(clientAddr, componentname, servicename) {
                var deferred = $q.defer();
                var url = "/component";
                var request = {
                    "url": url,
                    "dataType": "json",
                    "method": "GET",
                    "params": {
                        "clientAddr": clientAddr,
                        "appset_name": servicename,
                        "name":componentname
                    }
                }

                $http(request).success(function(data) {
                    deferred.resolve(data);
                }).error(function(error) {
                    deferred.reject(error);
                });
                return deferred.promise;
            },
            save: function(clientAddr, data, type) {
                var deferred = $q.defer();
                var method = type == "create" ? "POST" : "PUT";
                var url = "/component";
                var request = {
                    "url": url,
                    "dataType": "json",
                    "method": method,
                    "params": {
                        "clientAddr": clientAddr
                    },
                    "data": angular.toJson(data)

                }

                $http(request).success(function(data) {
                    deferred.resolve(data);
                }).error(function(error) {
                    deferred.reject(error);
                });
                return deferred.promise;
            },
            scale: function(clientAddr, data) {
                var deferred = $q.defer();
                var url = "/component/scale";
                var scaleto = data.operationType == "increase" ? parseInt(data.currentNum) + parseInt(data.increaseNum) : parseInt(data.currentNum) - parseInt(data.decreaseNum);
                var request = {
                    "url": url,
                    "dataType": "json",
                    "method": "PUT",
                    "params": {
                        "clientAddr": clientAddr,
                        "appset_name": data.appset,
                        "scaleto": scaleto,
                        "name":data.component
                    }

                }

                $http(request).success(function(data) {
                    deferred.resolve(data);
                }).error(function(error) {
                    deferred.reject(error);
                });
                return deferred.promise;
            },
            startOrStop: function(clientAddr, data, type) {
                var deferred = $q.defer();
                var url = "/component/" + type;
                var request = {
                    "url": url,
                    "dataType": "json",
                    "method": "PUT",
                    "params": {
                        "clientAddr": clientAddr,
                        "appset_name": data.appset_name,
                        "name":data.name
                    }

                }

                $http(request).success(function(data) {
                    deferred.resolve(data);
                }).error(function(error) {
                    deferred.reject(error);
                });
                return deferred.promise;
            },
            delete: function(clientAddr, data) {
                var deferred = $q.defer();
                var url = "/component";
                var request = {
                    "url": url,
                    "dataType": "json",
                    "method": "DELETE",
                    "params": {
                        "clientAddr": clientAddr,
                        "appset_name": data.appset_name,
                        "name":data.name
                    }

                }

                $http(request).success(function(data) {
                    deferred.resolve(data);
                }).error(function(error) {
                    deferred.reject(error);
                });
                return deferred.promise;
            },



        }

    }]);
});
