define(['app'], function (app) {
    'use strict';
     app.provide.factory('ServiceService', ['$http','$q',function ($http,$q) {
	    	return {              
			    get : function(clientAddr, skip, limit){
			    	var deferred = $q.defer();
					var url = "/appsets?count=true&skip_group=1&skip="+skip+"&limit="+limit;
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET",
						"params": {
						  "clientAddr": clientAddr
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    getDetail : function(clientAddr, servicename){
			    	var deferred = $q.defer();
					var url = "/appsets/"+servicename+"?skip_app=1";
					var request = {
						"url": url,
						"dataType": "json",
						"method": "GET",
						"params": {
						  "clientAddr": clientAddr
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    save : function(clientAddr, data){
                    data.group = data.group == "" ? {} : angular.fromJson(data.group);
                    var deferred = $q.defer();
					var url = "/appsets";
					var request = {
						"url": url,
						"dataType": "json",
						"method": "POST",
						"params": {
						  "clientAddr": clientAddr
					    },
						"data": angular.toJson(data)

					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    update : function(clientAddr, data){
                    data.group = data.group == "" ? {} : angular.fromJson(data.group);
                    var deferred = $q.defer();
					var url = "/appsets/"+data._id;
					var request = {
						"url": url,
						"dataType": "json",
						"method": "PUT",
						"params": {
						  "clientAddr": clientAddr
					    },
						"data": angular.toJson(data)

					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    delete : function(clientAddr, service){
                    var deferred = $q.defer();
					var url = "/appsets/" + service.name;
					var request = {
						"url": url,
						"dataType": "json",
						"method": "DELETE",
						"params": {
						  "clientAddr": clientAddr
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    stop : function(clientAddr, service){
                    var deferred = $q.defer();
					var url = "/appsets/" + service.name + "/stop";
					var request = {
						"url": url,
						"dataType": "json",
						"method": "PUT",
						"params": {
						  "clientAddr": clientAddr
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    },
			    start : function(clientAddr, service){
                    var deferred = $q.defer();
					var url = "/appsets/" + service.name + "/start";
					var request = {
						"url": url,
						"dataType": "json",
						"method": "PUT",
						"params": {
						  "clientAddr": clientAddr
					    }
					}
						
					$http(request).success(function(data){
						deferred.resolve(data);
					}).error(function(error){
						deferred.reject(error);
					});
					return deferred.promise;
			    }
			    


	    	}
	    	
     }]);
});