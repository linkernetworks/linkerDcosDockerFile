define(['app'], function(app) {
    'use strict';
    app.compileProvider.directive('oldpassword', ["$q", "$http","$cookies", function($q, $http,$cookies) {
        return {
            restrict: 'ACEM',
            require: 'ngModel',
            link: function(scope, elm, attrs, ctrl) {

                ctrl.$asyncValidators.oldpassword = function(modelValue, viewValue) {

                    if (ctrl.$isEmpty(modelValue)) {
                        // consider empty model valid
                        return $q.when();
                    }
                    var deferred = $q.defer();
                    var url = "/user/login";
                    var request = {
                        "url": url,
                        "dataType": "json",
                        "method": "POST",
                        "data": JSON.stringify({ "username": $cookies.get('username'), "password": viewValue })
                    }
                    $http(request).success(function(response) {
                        deferred.resolve(response);
                    }).error(function(error) {
                        deferred.reject(error);
                    });
                    return deferred.promise;

                };
            }
        };
    }]);
    app.compileProvider.directive('confirmpassword', ["$q", "$http", function($q, $http) {
        return {
            restrict: 'ACEM',
            require: 'ngModel',
            link: function(scope, elm, attrs, ctrl) {
                ctrl.$validators.confirmpassword = function(modelValue, viewValue) {
                    if (ctrl.$isEmpty(modelValue)) {
                        // consider empty models to be valid
                        return true;
                    }
                    var newpassword = scope.$parent.$parent.passwords.newpassword;
                    if (viewValue === newpassword) {
                        // it is valid
                        return true;
                    }

                    // it is invalid
                    return false;
                };
            }
        };
    }]);



});
