define(['app'], function(app) {
    'use strict';
    app.compileProvider.directive('status', function() {
        return {
            restrict: 'E',
            scope: {
              type: '@'             
            },
            template: '<span ng-class="{label:true, \'label-success\': type==\'RUNNING\'||type==\'success\'||type==\'TASK_RUNNING\', \'label-danger\': type==\'FAILED\' || type==\'STOPPED\'|| type==\'fail\' || type==\'DELETING\',\'label-warning\': type==\'TERMINATING\' || type==\'DEPLOYING\' || type==\'INSTALLING\'|| type==\'start\' ,\'label-info\': type==\'IDLE\'}">{{\'common.\' + type | translate}}</span>',
            replace: true      
        }
    });
});
