define(['app'], function(app) {
    'use strict';
    app.compileProvider.directive('status', function() {
        return {
            restrict: 'E',
            scope: {
              type: '@'             
            },
            template: '<span ng-class="{label:true, \'label-success\': type==\'RUNNING\'||type==\'success\', \'label-danger\': type==\'FAILED\' || type==\'STOPPED\'|| type==\'fail\',\'label-warning\': type==\'TERMINATING\' || type==\'DEPLOYING\',\'label-info\': type==\'IDLE\'}">{{\'common.\' + type | translate}}</span>',
            replace: true      
        }
    });
});
