define(['app', 'services/configuration/smtp','directives/pagination'], function(app) {
    'use strict';
    app.controllerProvider.register('SMTPController', ['$scope', '$uibModal', '$location', '$state', 'SMTPService', 'CommonService', 'ResponseService', function($scope, $uibModal, $location, $state, SMTPService,CommonService, ResponseService) {
        $scope.changeTab = function(target){
            $location.path('/configuration/'+target);

        }
        $scope.smtpservers = [];
        $scope.currentPage = 1;
        $scope.$watch('currentPage', function() {
            $scope.getSMTPServers();
        });
        $scope.totalPage = 1;
        $scope.recordPerPage = CommonService.recordNumPerPage();
        $scope.totalrecords = 0;

        $scope.getSMTPServers = function() {
            var skip = ($scope.currentPage - 1) * $scope.recordPerPage;
            var limit = $scope.recordPerPage;
            SMTPService.getSMTPServers(skip, limit).then(function(data) {
                    $scope.totalrecords = data.count;
                    $scope.totalPage = Math.ceil($scope.totalrecords / $scope.recordPerPage);
                    $scope.smtpservers = data.data;
                },
                function(error) {
                    ResponseService.errorResponse(error, "config.smtp.listFailed");
                })
        };

        $scope.addSMTPServer = function() {
            $uibModal.open({
                    templateUrl: 'templates/configuration/smtp/add.html',
                    controller: 'AddSMTPController',
                    backdrop: 'static',
                    resolve:{
                        model: function() {
                            return {
                                smtp: {
                                    "name":"",
                                    "passwd":"",
                                    "address":""
                                }
                            }
                        }
                    }
                })
                .result
                .then(function(response) {
                    if (response.operation === 'execute') {
                        $scope.doAdd(response.data);
                    }
                });
        };
        
        $scope.doAdd = function(smtp) {
            SMTPService.addSMTPServer(smtp).then(function(data) {
                    $scope.getSMTPServers();
            },
            function(error) {
                 ResponseService.errorResponse(error, "config.smtp.addFailed");
            })
        };

        $scope.editSMTPServer = function(smtp) {
            $uibModal.open({
                    templateUrl: 'templates/configuration/smtp/add.html',
                    controller: 'AddSMTPController',
                    backdrop: 'static',
                    resolve: {
                        model: function() {
                            return {
                                smtp: {
                                    "_id":smtp._id,
                                    "name":smtp.name,
                                    "passwd":smtp.passwd,
                                    "address":smtp.address
                                }
                            };
                        }
                    }
                })
                .result
                .then(function(response) {
                    if (response.operation === 'execute') {
                        $scope.doEdit(response.data);
                    }
                });
        };
        
        $scope.doEdit = function(smtp) {
            SMTPService.editSMTPServer(smtp).then(function(data) {
                    $scope.getSMTPServers();
            },
            function(error) {
                 ResponseService.errorResponse(error, "config.smtp.updateFailed");
            })
        };

        $scope.confirmDeleteSMTPServer = function(smtp) {
            $scope.$translate(['common.deleteConfirm', 'config.smtp.deleteMessage', 'common.delete']).then(function(translations) {
                $scope.confirm = {
                    "title": translations['common.deleteConfirm'],
                    "message": translations['config.smtp.deleteMessage'],
                    "button": {
                        "text": translations['common.delete'],
                        "action": function() {
                            $scope.deleteSMTPServer(smtp);
                        }
                    }

                };
                CommonService.deleteConfirm($scope);
            });
        };
        $scope.deleteSMTPServer = function(smtp) {
            SMTPService.deleteSMTPServer(smtp).then(function(data) {
                    $scope.getSMTPServers();
                },
                function(error) {
                    ResponseService.errorResponse(error, "config.smtp.deleteFailed");
                })
        };
    }]);

    app.controllerProvider.register('AddSMTPController', ['$scope', '$uibModalInstance','model',
        function($scope, $uibModalInstance, model) {
            $scope.smtp = model.smtp;

            $scope.close = function(res) {
                $uibModalInstance.close({
                    "operation": res,
                    "data": $scope.smtp
                });
            };
        }
    ]);
});
