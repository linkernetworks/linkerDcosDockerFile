define(['app', 'directives/pagination', 'services/user/main', 'services/configuration/platform'], function(app) {
	'use strict';
	app.controllerProvider.register('PlatformManagementController', ['$scope', '$uibModal', '$location', '$state','$cookies', 'CommonService', 'ResponseService', 'UserService', 'PlatformService', function($scope, $uibModal, $location, $state, $cookies,CommonService, ResponseService, UserService, PlatformService) {
		$scope.changeTab = function(target) {
			$location.path('/configuration/' + target);
		};
		$scope.currentUser = $cookies.get("username");
		$scope.types = [{
			name: 'openstack'
		}, {
			name: 'amazonec2'
		}];
		$scope.$watch('selectedUser', function(nv, ov) {
			if (nv == ov) {
				return
			}
			$scope.getPlatforms();
		});
		

		$scope.platforms = [];
		$scope.currentPage = 1;
		$scope.$watch('currentPage', function() {
			$scope.getPlatforms();
		});
		$scope.totalPage = 1;
		$scope.recordPerPage = CommonService.recordNumPerPage();
		$scope.totalrecords = 0;
		$scope.getPlatforms = function() {
			//if (CommonService.clusterAvailable()) {
			var skip = ($scope.currentPage - 1) * $scope.recordPerPage;
			var limit = $scope.recordPerPage;
			PlatformService.getProvider(limit, skip).then(function(data) {
						$scope.totalrecords = data.count;
						$scope.totalPage = Math.ceil($scope.totalrecords / $scope.recordPerPage);
						$scope.platforms = data.data;
					},
					function(error) {
						ResponseService.errorResponse(error);
					})
				//}
		};
		$scope.createPlatform = function() {
			$uibModal.open({
					templateUrl: 'templates/configuration/platform/create.html',
					controller: 'CreatePlatformController',
					backdrop: 'static',
					resolve: {
						model: function() {
							return {
								types: $scope.types
							};
						}
					}
				})
				.result
				.then(function(response) {
					if (response.operation === 'execute') {
						PlatformService.createProvider(response.data).then(function(data) {
								$scope.getPlatforms();
							},
							function(error) {
								ResponseService.errorResponse(error);
							});
					}
				});
		};
		$scope.editPlatform = function(platform) {
			$uibModal.open({
					templateUrl: 'templates/configuration/platform/edit.html',
					controller: 'EditPlatformController',
					backdrop: 'static',
					resolve: {
						model: function() {
							return {
								platform: platform,
								types: $scope.types
							};
						}
					}
				})
				.result
				.then(function(response) {
					if (response.operation === 'execute') {
						PlatformService.editProvider(response.data).then(function(data) {
								$scope.getPlatforms();
							},
							function(error) {
								ResponseService.errorResponse(error);
							});
					}
				});
		};
		$scope.deletePlatform = function(platform) {
			$scope.$translate(['common.deleteConfirm', 'config.platform.delete', 'common.delete']).then(function(translations) {
				$scope.confirm = {
					"title": translations['common.deleteConfirm'],
					"message": translations['config.platform.delete'],
					"button": {
						"text": translations['common.delete'],
						"action": function() {
							PlatformService.deleteProvider(platform).then(function(data) {
									$scope.getPlatforms();
								},
								function(error) {
									ResponseService.errorResponse(error);
								});
						}
					}
				};
				CommonService.deleteConfirm($scope);
			});
		};
	}]);

	app.controllerProvider.register('CreatePlatformController', ['$scope', '$uibModalInstance', 'model', 'PlatformService',
		function($scope, $uibModalInstance, model, PlatformService) {
			$scope.validate = true;
			$scope.types = model.types;
			$scope.platform = {
				"type": $scope.types[0].name,
				"sshuser": "",
				"openstackInfo": {
					"authUrl": "",
					"username": "",
					"password": "",
					"tenantName": "",
					"flavorName": "",
					"imageName": "",
					"securityGroup": "",
					"ipPoolName": "",
					"novaNetwork": ""
				},
				"awsEc2Info": {
					"accesskeys": "",
					"secretKey": "",
					"imageId": "",
					"instanceType": "",
					"rootSize": "",
					"region": "",
					"vpcId": ""
				}
			};
			$scope.validateName = function() {
				var platformname = $scope.platform.name;
				if (!angular.isUndefined(platformname) && !_.isEmpty(platformname)) {
					PlatformService.validateName(platformname).then(function(data) {
							$scope.validate = true;
						},
						function(errorMessage) {
							$scope.validate =false;
						});
				} else {
					$scope.validate = true;
				}

			};
			$scope.$watch('platform.type', function() {
				if ($scope.platform.type == "openstack") {
					for (var i in $scope.platform.openstackInfo) {
						$scope.platform.openstackInfo[i] = "";
					}
				} else {
					for (var i in $scope.platform.awsEc2Info) {
						$scope.platform.awsEc2Info[i] = "";
					}
				}

			});
			$scope.close = function(res) {
				$uibModalInstance.close({
					"operation": res,
					"data": $scope.platform
				});
			};
		}
	]);
	app.controllerProvider.register('EditPlatformController', ['$scope', '$uibModalInstance', 'model',
		function($scope, $uibModalInstance, model) {
			$scope.types = model.types;
			$scope.platform = {};
			angular.copy(model.platform, $scope.platform);
			$scope.close = function(res) {
				$uibModalInstance.close({
					"operation": res,
					"data": $scope.platform
				});
			};
		}
	]);
	app.controllerProvider.register('DeletePlatformController', ['$scope', '$uibModalInstance', 'model',
		function($scope, $uibModalInstance, model) {
			$scope.platform = model.platform;
			$scope.close = function(res) {
				$uibModalInstance.close({
					"operation": res,
					"data": $scope.platform
				});
			};
		}
	]);

});