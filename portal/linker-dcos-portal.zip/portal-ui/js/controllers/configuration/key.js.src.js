define(['app', 'services/configuration/key','services/user/main','directives/pagination'], function(app) {
    'use strict';
    app.controllerProvider.register('KeyPairController', ['$scope', '$uibModal', '$location', '$state','$cookies', 'KeyPairService', 'UserService','CommonService', 'ResponseService', function($scope, $uibModal, $location, $state, $cookies, KeyPairService,UserService,CommonService, ResponseService) {
        $scope.changeTab = function(target){
            $location.path('/configuration/'+target);

        }
        $scope.currentUser = $cookies.get("username");
        $scope.keypairs = [];
        $scope.users = [];
        $scope.currentPage = 1;
        $scope.$watch('currentPage', function() {
            $scope.getKeyPairs();
        });
        $scope.totalPage = 1;
        // $scope.recordPerPage = CommonService.recordNumPerPage();
        $scope.recordPerPage = 2;
        $scope.totalrecords = 0;

        // $scope.getUsers = function() {
        //     UserService.getUsers(0, 0).then(function(data) {
        //             $scope.users = data.data;
        //             if(!_.isUndefined($scope.keypairs) && $scope.keypairs.length>0){
        //                  _.each($scope.keypairs,function(key){
        //                     key.user_name = $scope.getUserName(key.user_id);
        //                 })
        //             }
        //         },
        //         function(error) {
        //             ResponseService.errorResponse(error, "user.listFailed");
        //         })
        // };
        // $scope.getUsers();

        // $scope.getUserName = function(userid){
        //     return _.find($scope.users,function(user){
        //         return user._id == userid;
        //     }).username;
        // }

        $scope.getKeyPairs = function() {
            var skip = ($scope.currentPage - 1) * $scope.recordPerPage;
            var limit = $scope.recordPerPage;
            KeyPairService.getKeyPairs(skip, limit).then(function(data) {
                    $scope.totalrecords = data.count;
                    $scope.totalPage = Math.ceil($scope.totalrecords / $scope.recordPerPage);
                    // if(!_.isUndefined($scope.users) && $scope.users.length>0){
                    //      _.each(data.data,function(key){
                    //         key.user_name = $scope.getUserName(key.user_id);
                    //     })
                    // }
                   
                    $scope.keypairs = data.data;
                },
                function(error) {
                    ResponseService.errorResponse(error, "config.key.listFailed");
                })
        };

        $scope.createKeyPair = function() {
            $uibModal.open({
                    templateUrl: 'templates/configuration/key/create.html',
                    controller: 'CreateKeyPairController',
                    backdrop: 'static'
                    // resolve: {
                    //     model: function() {
                    //         return {
                    //             users: $scope.users
                    //         };
                    //     }
                    // }
                })
                .result
                .then(function(response) {
                    if (response.operation === 'execute') {
                        $scope.doCreate(response.data);
                    }
                });
        };
        
        $scope.doCreate = function(keypair) {
            KeyPairService.createKeyPair(keypair).then(function(data) {
                    $scope.downloadPrivateKey(data.data);
            },
            function(error) {
                 ResponseService.errorResponse(error, "config.key.createFailed");
            })
        };

        $scope.downloadPrivateKey = function(data){
            $uibModal.open({
                    templateUrl: 'templates/configuration/key/download.html',
                    controller: 'DownloadKeyPairController',
                    backdrop: 'static'
                });
            window.location.assign("/keypair/download/"+data);
            $scope.getKeyPairs();               
        }

        $scope.doDownload = function(userid) {
            KeyPairService.downloadKeyPair(userid).then(function(data) {
                    $scope.getKeyPairs();
            },
            function(error) {
                 ResponseService.errorResponse(error, "config.key.downloadFailed");
            })
        };

        $scope.uploadKeyPair = function() {
            $uibModal.open({
                    templateUrl: 'templates/configuration/key/upload.html',
                    controller: 'UploadKeyPairController',
                    backdrop: 'static'
                    // resolve: {
                    //     model: function() {
                    //         return {
                    //             users: $scope.users
                    //         };
                    //     }
                    // }
                })
                .result
                .then(function(response) {
                    if (response.operation === 'execute') {
                        $scope.doUpload(response.data);
                    }
                });
        };
        
        $scope.doUpload = function(keypair) {
            KeyPairService.uploadKeyPair(keypair).then(function(data) {
                    $scope.getKeyPairs();
            },
            function(error) {
                 ResponseService.errorResponse(error, "config.key.uploadFailed");
            })
        };

        $scope.confirmDeleteKey = function(key) {
            $scope.$translate(['common.deleteConfirm', 'config.key.deleteMessage', 'common.delete']).then(function(translations) {
                $scope.confirm = {
                    "title": translations['common.deleteConfirm'],
                    "message": translations['config.key.deleteMessage'],
                    "button": {
                        "text": translations['common.delete'],
                        "action": function() {
                            $scope.deleteKeyPair(key);
                        }
                    }

                };
                CommonService.deleteConfirm($scope);
            });
        };
        $scope.deleteKeyPair = function(key) {
            KeyPairService.deleteKeyPair(key).then(function(data) {
                    $scope.getKeyPairs();
                },
                function(error) {
                    ResponseService.errorResponse(error, "config.key.deleteFailed");
                })
        };
    }]);

    app.controllerProvider.register('CreateKeyPairController', ['$scope','$uibModalInstance',
        function($scope, $uibModalInstance) {
            // $scope.users = model.users;
            $scope.keypair = {
                "name": ""
                // "user_id":$scope.users[0]._id
            };

            $scope.close = function(res) {
                $uibModalInstance.close({
                    "operation": res,
                    "data": $scope.keypair
                });
            };
        }
    ]);

    app.controllerProvider.register('DownloadKeyPairController', ['$scope', '$uibModalInstance',
        function($scope, $uibModalInstance) {
            $scope.close = function(res) {
                $uibModalInstance.close({
                    "operation": res
                });
            };
        }
    ]);

    app.controllerProvider.register('UploadKeyPairController', ['$scope', '$uibModalInstance',
        function($scope, $uibModalInstance) {
            // $scope.users = model.users;
            $scope.keypair = {
                "name": "",
                // "user_id":$scope.users[0]._id,
                "pubkey_value": ""
            };

            $scope.close = function(res) {
                $uibModalInstance.close({
                    "operation": res,
                    "data": $scope.keypair
                });
            };
        }
    ]);
});
