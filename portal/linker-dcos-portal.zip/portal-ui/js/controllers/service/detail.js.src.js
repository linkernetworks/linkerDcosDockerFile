define(['app', 'services/service/main', 'services/serviceGraph/main', 'services/serviceGraph/dataParser', 'services/serviceGraph/groupParser', 'services/service/component', 'services/service/container', 'directives/status'], function(app) {
    'use strict';
    app.controllerProvider.register('ServiceDetailController', ['$scope', '$uibModal', '$state', '$sessionStorage', 'ServiceService', 'CommonService', 'ResponseService', 'ComponentService','ContainerService', 'ServiceGraphService', 'treeUtilService', 'componentTreeUtilService', function($scope, $uibModal, $state, $sessionStorage, ServiceService, CommonService, ResponseService, ComponentService,ContainerService, ServiceGraphService, treeUtilService, componentTreeUtilService) {

        $scope.$storage = $sessionStorage;
        $scope.$watch('$storage.cluster', function(newValue, oldValue) {
            if (!_.isUndefined(newValue) && !_.isUndefined(oldValue) && newValue._id != oldValue._id) {
                $state.go("service");
            }

        }, true);

        $scope.componentObj = {};
        $scope.selectedService = {};
        $scope.jsonString = "";
        $scope.showDetail = function() {
            if (CommonService.endPointAvailable()) {
                ServiceService.getDetail(CommonService.getEndPoint(), $state.params.serviceName).then(function(data) {
                        $scope.selectedService = data.data;
                        _.each(data.data.component_names, function(componentname) {
                            ComponentService.getDetail(CommonService.getEndPoint(), componentname, $state.params.serviceName).then(function(data) {
                                $scope.componentObj[componentname] = data.data;
                            }, function(error) {
                                ResponseService.errorResponse(error, "service.componentListFailed");
                            })
                        })
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "service.componentListFailed");
                    })
            }
        };
        $scope.createComponent = function() {
            $uibModal.open({
                    templateUrl: 'templates/service/createComponent.html',
                    controller: 'CreateComponentController',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        model: function() {
                            return {
                                components: $scope.selectedService.component_names || []
                            };
                        }
                    }
                })
                .result
                .then(function(response) {
                    if (response.operation === 'execute') {
                        $scope.saveComponent(response.data, "create");
                    }
                });
        };
        $scope.saveComponent = function(component, type) {
            if (CommonService.endPointAvailable()) {
                ComponentService.save(CommonService.getEndPoint(), component, type).then(function(data) {
                        $scope.showDetail();
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "service.componentsaveFailed");
                    })
            }
        };
        $scope.prepareScale = function(component) {
            $uibModal.open({
                    templateUrl: 'templates/service/scaleContainer.html',
                    controller: 'ScaleContainerController',
                    backdrop: 'static',
                    // size: 'lg',
                    resolve: {
                        model: function() {
                            return {
                                component: component
                            };
                        }
                    }
                })
                .result
                .then(function(response) {
                    if (response.operation === 'execute') {
                        $scope.scaleContainer(response.data);
                    }
                });
        };
        $scope.scaleContainer = function(info) {
            if (CommonService.endPointAvailable()) {
                ComponentService.scale(CommonService.getEndPoint(), info).then(function(data) {
                        $scope.showDetail();
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "service.componentscaleFailed");
                    })
            }
        };
        $scope.prepareEdit = function(component) {
            $uibModal.open({
                    templateUrl: 'templates/service/editComponent.html',
                    controller: 'EditComponentController',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        model: function() {
                            return {
                                component: component,
                                componentList: $scope.selectedService.component_names || []
                            };
                        }
                    }
                })
                .result
                .then(function(response) {
                    if (response.operation === 'execute') {
                        $scope.saveComponent(response.data, "edit");
                    }
                });
        };
        $scope.startOrStopComponent = function(component, type){
            if (CommonService.endPointAvailable()) {
                ComponentService.startOrStop(CommonService.getEndPoint(), component, type).then(function(data) {
                        $scope.showDetail();
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "service.component"+type+"Failed");
                    })
            }
        };
        $scope.confirmDelete = function(component) {
            $scope.$translate(['common.deleteConfirm', 'service.deleteMessage', 'common.delete']).then(function(translations) {
                $scope.confirm = {
                    "title": translations['common.deleteConfirm'],
                    "message": translations['service.deleteMessage'],
                    "button": {
                        "text": translations['common.delete'],
                        "action": function() {
                            $scope.deleteComponent(component);
                        }
                    }

                };
                CommonService.deleteConfirm($scope);
            });
        };
        $scope.deleteComponent = function(component) {
            ComponentService.delete(CommonService.getEndPoint(),component).then(function(data) {
                    $scope.showDetail();
                },
                function(error) {
                    ResponseService.errorResponse(error, "component.deleteFailed");
                })
        };
        $scope.restart = function(containerId,componentname){
            if (CommonService.endPointAvailable()) {               
                ContainerService.restart(CommonService.getEndPoint(), containerId, $scope.selectedService.name,componentname).then(function(data) {            
                        $scope.showDetail();
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "container.getFailed");
                    })
            }
        };
        

        $scope.zoomingRate = 0.85;
        $scope.showJSON = function() {
            $scope.selectedModel = $scope.selectedService.group;
            $scope.jsonString = JSON.stringify($scope.selectedModel, undefined, 2);
        };
        $scope.showGraph = function() {
            $scope.selectedModel = $scope.selectedService.group;

            treeUtilService.allocateImageToApp($scope.selectedModel);
            $scope.modelDesignerHeight = 560;

            //parse service json
            $scope.nodes = [];
            $scope.relations = [];
            $scope.extra_relations = [];

            //for data with groups 
            // $scope.levelHeights = [];

            //get root path
            var rootPathID = $scope.selectedModel.id;
            //parse selectedModel json
            $scope.relations = componentTreeUtilService.parseGroup(rootPathID, $scope.selectedModel, $scope.nodes, $scope.relations, $scope.extra_relations, $scope.zoomingRate);
            //for data with groups 
            // $scope.relations = treeUtilService.parseService(rootPathID, $scope.selectedModel, $scope.nodes, $scope.relations, $scope.extra_relations, $scope.levelHeights, $scope.zoomingRate, "model");

            var treejson = _.find($scope.nodes, function(node) {
                return node.id == rootPathID;
            })


            setTimeout(function() {
                ServiceGraphService.drawComponentGraph("serviceGraphDiv", treejson, $scope);
                 //for data with groups
                // ServiceGraphService.drawGraph("serviceGraphDiv", treejson, $scope);
            }, 500)
        };

        // component relations
        $scope.checkIfComponentsHaveDependencies = function(group) {
            var result = false;
            _.each(group.apps, function(app) {
                if (!_.isUndefined(app.dependencies)) {
                    result = true;
                }
            })
            return result;
        }

        $scope.showComponentDependencies = function(event) {
            var groupid = $(event.currentTarget).parent().find(".group-label").data("groupid");
            var group = _.find($scope.nodes, function(node) {
                return node.id == groupid;
            }).data;

            //parse service json
            $scope.c_nodes = [];
            $scope.c_relations = [];
            $scope.c_extra_relations = [];

            //get root path
            var rootPathID = group.pathid;
            //parse selectedModel json
            $scope.c_relations = componentTreeUtilService.parseGroup(rootPathID, group, $scope.c_nodes, $scope.c_relations, $scope.c_extra_relations, $scope.zoomingRate);

            var treejson = _.find($scope.c_nodes, function(node) {
                return node.id == rootPathID;
            })

            $uibModal.open({
                templateUrl: 'templates/service/componentRelationGraph.html',
                controller: 'ComponentRelationController',
                backdrop: 'static',
                size: 'lg',
                resolve: {
                    model: function() {
                        return {
                            data: treejson,
                            reuselines: $scope.c_extra_relations
                        };
                    }
                }
            });
        }

        //zoom
        $scope.zoomin = function() {
            $scope.zoomingRate = $scope.zoomingRate  / 0.9;
            $scope.drawServiceGroup();
        };
        $scope.zoomout = function() {
            $scope.zoomingRate = $scope.zoomingRate * 0.9;
            $scope.drawServiceGroup();
        };

        $scope.getZoomingValue = function(target, property) {
            return treeUtilService.getZoomingValue(target, property, $scope.zoomingRate);
        };

        $scope.getZoomingCssString = function(target) {
            return treeUtilService.getZoomingCssString(target, $scope.zoomingRate);
        };
        $scope.editJSON = function(){
              $uibModal.open({
                    templateUrl: 'templates/service/editJSON.html',
                    controller: 'EditJSONController',
                    backdrop: 'static',
                    size:"lg",
                    resolve: {
                        model: function() {
                            return {
                                service: $scope.selectedService
                            };
                        }
                    }
                })
                .result
                .then(function(response) {
                    if (response.operation === 'execute') {
                        $scope.saveService(response.data);
                    }
                });
        };
        $scope.saveService = function(service) {
            if (CommonService.endPointAvailable()) {              
                ServiceService.update(CommonService.getEndPoint(),service).then(function(data) {
                        $scope.getServices();
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "service.updateFailed");
                    })
            }
        };
       
        $scope.showDetail();

    }]);

    app.controllerProvider.register('ComponentRelationController', ['$scope', '$uibModalInstance', 'model', 'ServiceGraphService', 'treeUtilService',
        function($scope, $uibModalInstance, model, ServiceGraphService, treeUtilService) {
            $scope.extra_relations = model.reuselines;

            $scope.zoomingRate = 1;
            //zoom
            $scope.zoomin = function() {
                $scope.zoomingRate = $scope.zoomingRate  / 0.9;
                $scope.drawComponentGraph();
            };
            $scope.zoomout = function() {
                $scope.zoomingRate = $scope.zoomingRate * 0.9;
                $scope.drawComponentGraph();
            };

            $scope.getZoomingValue = function(target, property) {
                return treeUtilService.getZoomingValue(target, property, $scope.zoomingRate);
            };

            $scope.getZoomingCssString = function(target) {
                return treeUtilService.getZoomingCssString(target, $scope.zoomingRate);
            };

            $scope.drawComponentGraph = function() {
                ServiceGraphService.drawComponentGraph("componentGraphDiv", model.data, $scope);
            };

            $scope.close = function() {
                $uibModalInstance.close();
            };

            setTimeout(function() {
                $scope.drawComponentGraph();
            }, 500)
        }
    ]);

    app.controllerProvider.register('CreateComponentController', ['$scope', '$uibModalInstance', '$state', 'ComponentService', 'model',
        function($scope, $uibModalInstance, $state, ComponentService, model) {

            var componentJSON_1 = ComponentService.componentJSON().JSONTemplate;
            var portMapping_1 = ComponentService.componentJSON().portMapping;
            var volume_1 = ComponentService.componentJSON().volume;

            $scope.componentJSON = _.clone(componentJSON_1);
            $scope.component = { "appset_name": $state.params.serviceName, "name": "", "description": "", "app": $scope.componentJSON.marathon_app };

            $scope.portArray = [_.clone(portMapping_1)];
            $scope.volumeArray = [_.clone(volume_1)];

            $scope.envArray = [{ "key": "", "value": "" }];
            $scope.labelArray = [{ "key": "HAPROXY_GROUP", "value": "linkermgmt" }];
            $scope.constraintArray = [{ "key": "", "constraint": "UNIQUE", "value": "" }];
            $scope.relationshipArray = [];
            $scope.argArray = [{ "value": "" }];


            $scope.componentList = _.difference(model.components, $scope.relationshipArray);
            $scope.dependency = { "selectedComponent": $scope.componentList[0] };

            $scope.advance = { "isAlarm": false };
            $scope.alarmObj = { "upperLimit": "", "lowerLimit": "", "cpuUpperLimit": "","cpuLowerLimit":"", "memoryUpperLimit": "","memoryLowerLimit":"" };

            $scope.stepObj = { "previous": "", "current": "basic", "next": "container" };
            $scope.goNext = function(current) {
                $scope.stepObj = ComponentService.goNext(current);
            };
            $scope.goPrevious = function(current) {
                $scope.stepObj = ComponentService.goPrevious(current);
            };
            $scope.setCurrent = function(current) {
                $scope.stepObj = ComponentService.setCurrent(current);
            };
            $scope.addParameter = function(type) {
                switch (type) {
                    case "port":
                        $scope.portArray.push(_.clone(portMapping_1));
                        break;
                    case "env":
                        $scope.envArray.push({ "key": "", "value": "" });
                        break;
                    case "volume":
                        $scope.volumeArray.push(_.clone(volume_1));
                        break;
                    case "constraint":
                        $scope.constraintArray.push({ "key": "", "constraint": "UNIQUE", "value": "" });
                        break;
                    case "relationship":
                        $scope.relationshipArray.push($scope.dependency.selectedComponent);
                        $scope.componentList = _.difference(model.components, $scope.relationshipArray);
                        $scope.dependency = { "selectedComponent": $scope.componentList[0] };
                        break;
                    case "arg":
                        $scope.argArray.push({ "value": "" });
                        break;
                    case "label":
                        $scope.labelArray.push({ "key": "", "value": "" });
                        break;
                }
            };
            $scope.removeParameter = function(type, index) {
                switch (type) {
                    case "port":
                        $scope.portArray.splice(index, 1);
                        break;
                    case "env":
                        $scope.envArray.splice(index, 1);
                        break;
                    case "volume":
                        $scope.volumeArray.splice(index, 1);
                        break;
                    case "constraint":
                        $scope.constraintArray.splice(index, 1);
                        break;
                    case "relationship":
                        $scope.relationshipArray.splice(index, 1);
                        $scope.componentList = _.difference(model.components, $scope.relationshipArray);
                        $scope.dependency = { "selectedComponent": $scope.componentList[0] };
                        break;
                    case "arg":
                        $scope.argArray.splice(index, 1);
                        break;
                    case "label":
                        $scope.labelArray.splice(index, 1);
                        break;
                }
            };
            $scope.assembleData = function() {
                $scope.componentJSON.marathon_app.container.docker.portMappings = $scope.portArray;
                $scope.componentJSON.marathon_app.container.volumes = _.filter($scope.volumeArray,function(item){
                   return item.containerPath != "" && item.hostPath != "";
                });
                if ($scope.advance.isAlarm) {
                    var tempArray = [{ "key": "INSTANCE_MAX_NUM", "value": $scope.alarmObj.upperLimit },
                        { "key": "INSTANCE_MIN_NUM", "value": $scope.alarmObj.lowerLimit },
                        { "key": "CPU_HIGH_THRESHOLD", "value": $scope.alarmObj.cpuUpperLimit },
                        { "key": "MEM_HIGH_THRESHOLD", "value": $scope.alarmObj.memoryUpperLimit },
                        { "key": "CPU_LOW_THRESHOLD", "value": $scope.alarmObj.cpuLowerLimit },
                        { "key": "MEM_LOW_THRESHOLD", "value": $scope.alarmObj.memoryLowerLimit },
                        { "key": "ALERT_ENABLE", "value": "true" }
                    ];
                    $scope.envArray = $scope.envArray.concat(tempArray);
                }
                var envKeys = _.without(_.pluck($scope.envArray, 'key'),"");
                var envValues = _.without(_.pluck($scope.envArray, 'value'),"");
                $scope.componentJSON.marathon_app.env = _.object(envKeys, envValues);
                var labelKeys = _.without(_.pluck($scope.labelArray, 'key'),"");
                var labelValues = _.without(_.pluck($scope.labelArray, 'value'),"");
                $scope.componentJSON.marathon_app.labels = _.object(labelKeys, labelValues);
                var finalConstraintArray = [];
                _.each($scope.constraintArray, function(constraint) {
                    var tempArray = [];
                    if (constraint.key != "") {
                        tempArray.push(constraint.key);
                        tempArray.push(constraint.constraint);
                        tempArray.push(constraint.value);
                        finalConstraintArray.push(tempArray);
                    }

                })
                $scope.componentJSON.marathon_app.constraints = finalConstraintArray;
                $scope.componentJSON.marathon_app.dependencies = $scope.relationshipArray;
                $scope.componentJSON.marathon_app.args = _.without(_.pluck($scope.argArray, 'value'),"");
                $scope.componentJSON.marathon_app.id = $scope.component.name;
            };
            $scope.close = function(res) {
                if (res === "execute") {
                    $scope.assembleData();
                }
                $uibModalInstance.close({
                    "operation": res,
                    "data": $scope.component
                });
            };
        }
    ]);

    app.controllerProvider.register('ScaleContainerController', ['$scope', '$uibModalInstance', 'model',
        function($scope, $uibModalInstance, model) {
            $scope.container = { "operationType": "increase", "increaseNum": 1, "decreaseNum": 1, "currentNum": model.component.container_infos.length, "component": model.component.name, "appset": model.component.appset_name };
            $scope.close = function(res) {
                $uibModalInstance.close({
                    "operation": res,
                    "data": $scope.container
                });
            };
        }
    ]);
    app.controllerProvider.register('EditComponentController', ['$scope', '$uibModalInstance','$state','ComponentService', 'model',
        function($scope, $uibModalInstance, $state, ComponentService, model) {
            $scope.stepObj = { "previous": "", "current": "basic", "next": "container" };
            $scope.goNext = function(current) {
                $scope.stepObj = ComponentService.goNext(current);
            };
            $scope.goPrevious = function(current) {
                $scope.stepObj = ComponentService.goPrevious(current);
            };
            $scope.setCurrent = function(current) {
                $scope.stepObj = ComponentService.setCurrent(current);
            };
            $scope.component = _.clone(model.component);
            var componentJSON_1 = ComponentService.componentJSON().JSONTemplate;
            var portMapping_1 = ComponentService.componentJSON().portMapping;
            var volume_1 = ComponentService.componentJSON().volume;

            $scope.componentJSON = _.clone(componentJSON_1);
            $scope.componentRequest = { "_id":$scope.component._id,"appset_name": $state.params.serviceName, "name": $scope.component.name, "description": $scope.component.description, "app": $scope.component.app };

            $scope.advance = { "isAlarm": false };
            $scope.alarmObj = { "upperLimit": "", "lowerLimit": "", "cpuUpperLimit": "","cpuLowerLimit":"", "memoryUpperLimit": "","memoryLowerLimit":"" };
            
            
           
            $scope.envArray = [];
            $scope.labelArray = [];
            $scope.portArray = $scope.component.app.container.docker.portMappings;
            $scope.volumeArray = $scope.component.app.container.volumes;
            $scope.constraintArray = [];
            $scope.relationshipArray = [];
            $scope.argArray = [];
            var monitorKeyArray = ["ALERT_ENABLE","CPU_HIGH_THRESHOLD","CPU_LOW_THRESHOLD","INSTANCE_MAX_NUM","INSTANCE_MIN_NUM","MEM_HIGH_THRESHOLD","MEM_LOW_THRESHOLD"];           
            var customEnv = _.omit($scope.component.app.env, monitorKeyArray);
            var monitorEnv = _.pick($scope.component.app.env, monitorKeyArray);
            if(!_.isEqual(monitorEnv,{})){
                $scope.advance = { "isAlarm": true };
                $scope.alarmObj = { "upperLimit": monitorEnv.INSTANCE_MAX_NUM, "lowerLimit": monitorEnv.INSTANCE_MIN_NUM, "cpuUpperLimit": monitorEnv.CPU_HIGH_THRESHOLD, "cpuLowerLimit": monitorEnv.CPU_LOW_THRESHOLD,"memoryUpperLimit": monitorEnv.MEM_HIGH_THRESHOLD,"memoryLowerLimit": monitorEnv.MEM_LOW_THRESHOLD,"ALERT_ENABLE":true};
            }
            _.each(customEnv,function(value,key){               
                $scope.envArray.push({"key":key,"value":value});
            });
            _.each($scope.component.app.labels,function(value,key){               
                $scope.labelArray.push({"key":key,"value":value});
            });
            _.each($scope.component.app.args,function(value){               
                $scope.argArray.push({"value":value});
            });
            _.each($scope.component.app.constraints,function(value){               
                $scope.constraintArray.push({ "key": value[0], "constraint": value[1], "value": value[2] });
            });
            $scope.component.app.cmd = $scope.component.app.cmd || "";
            $scope.relationshipArray = $scope.component.app.dependencies || [];
            $scope.componentList = _.without(_.difference(model.componentList, $scope.relationshipArray), $scope.component.name);
            $scope.dependency = { "selectedComponent": $scope.componentList[0] };

            $scope.addParameter = function(type) {
                switch (type) {
                    case "port":
                        $scope.portArray.push(_.clone(portMapping_1));
                        break;
                    case "env":
                        $scope.envArray.push({ "key": "", "value": "" });
                        break;
                    case "volume":
                        $scope.volumeArray.push(_.clone(volume_1));
                        break;
                    case "constraint":
                        $scope.constraintArray.push({ "key": "", "constraint": "UNIQUE", "value": "" });
                        break;
                    case "relationship":
                        $scope.relationshipArray.push($scope.dependency.selectedComponent);
                        $scope.componentList = _.without(_.difference(model.componentList, $scope.relationshipArray), $scope.component.name);
                        $scope.dependency = { "selectedComponent": $scope.componentList[0] };
                        break;
                    case "arg":
                        $scope.argArray.push({ "value": "" });
                        break;
                    case "label":
                        $scope.labelArray.push({ "key": "", "value": "" });
                        break;
                }
            };
            $scope.removeParameter = function(type, index) {
                switch (type) {
                    case "port":
                        $scope.portArray.splice(index, 1);
                        break;
                    case "env":
                        $scope.envArray.splice(index, 1);
                        break;
                    case "volume":
                        $scope.volumeArray.splice(index, 1);
                        break;
                    case "constraint":
                        $scope.constraintArray.splice(index, 1);
                        break;
                    case "relationship":
                        $scope.relationshipArray.splice(index, 1);
                        $scope.componentList = _.without(_.difference(model.componentList, $scope.relationshipArray), $scope.component.name);
                        $scope.dependency = { "selectedComponent": $scope.componentList[0] };
                        break;
                    case "arg":
                        $scope.argArray.splice(index, 1);
                        break;
                    case "label":
                        $scope.labelArray.splice(index, 1);
                        break;
                }
            };
            $scope.assembleData = function() {
                $scope.component.app.container.docker.portMappings = $scope.portArray;
                $scope.component.app.container.volumes = _.filter($scope.volumeArray,function(item){
                   return item.containerPath != "" && item.hostPath != "";
                });
                if ($scope.advance.isAlarm) {
                    var tempArray = [{ "key": "INSTANCE_MAX_NUM", "value": $scope.alarmObj.upperLimit },
                        { "key": "INSTANCE_MIN_NUM", "value": $scope.alarmObj.lowerLimit },
                        { "key": "CPU_HIGH_THRESHOLD", "value": $scope.alarmObj.cpuUpperLimit },
                        { "key": "MEM_HIGH_THRESHOLD", "value": $scope.alarmObj.memoryUpperLimit },
                        { "key": "CPU_LOW_THRESHOLD", "value": $scope.alarmObj.cpuLowerLimit },
                        { "key": "MEM_LOW_THRESHOLD", "value": $scope.alarmObj.memoryLowerLimit },
                        { "key": "ALERT_ENABLE", "value": "true" }
                    ];
                    $scope.envArray = $scope.envArray.concat(tempArray);
                }

                var envKeys = _.without(_.pluck($scope.envArray, 'key'),"");
                var envValues = _.without(_.pluck($scope.envArray, 'value'),"");
                $scope.component.app.env = _.object(envKeys, envValues);
                var labelKeys = _.without(_.pluck($scope.labelArray, 'key'),"");
                var labelValues = _.without(_.pluck($scope.labelArray, 'value'),"");
                $scope.component.app.labels = _.object(labelKeys, labelValues);
                var finalConstraintArray = [];
                _.each($scope.constraintArray, function(constraint) {
                    var tempArray = [];
                    if (constraint.key != "") {
                        tempArray.push(constraint.key);
                        tempArray.push(constraint.constraint);
                        tempArray.push(constraint.value);
                        finalConstraintArray.push(tempArray);
                    }

                })
                $scope.component.app.constraints = finalConstraintArray;
                $scope.component.app.dependencies = $scope.relationshipArray;
                $scope.component.app.args = _.without(_.pluck($scope.argArray, 'value'),"");
            };
            $scope.close = function(res) {
                if (res === "execute") {
                    $scope.assembleData();
                }
                $uibModalInstance.close({
                    "operation": res,
                    "data": $scope.componentRequest
                });
            };
            
        }
    ]);
    app.controllerProvider.register('EditJSONController', ['$scope', '$uibModalInstance', 'model',
        function($scope, $uibModalInstance, model) {
            $scope.service = _.clone(model.service);
            $scope.service.group = JSON.stringify($scope.service.group);
            $scope.close = function(res) {
                $uibModalInstance.close({
                    "operation": res,
                    "data": $scope.service
                });
            };
        }
    ]);



});
