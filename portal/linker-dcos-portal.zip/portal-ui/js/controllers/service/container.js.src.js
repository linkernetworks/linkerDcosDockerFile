define(['app', 'services/service/container','directives/status'], function(app) {
    'use strict';
    app.controllerProvider.register('ContainerController', ['$scope', '$uibModal', '$sessionStorage', '$state','$location','ContainerService', 'CommonService', 'ResponseService',  function($scope, $uibModal, $sessionStorage,$state, $location,ContainerService, CommonService, ResponseService) {
        
        $scope.$storage = $sessionStorage;
        $scope.container = {};
        $scope.component = $scope.$storage.component = $state.params.component ||  $scope.$storage.component;
        $scope.containerId = $scope.$storage.containerId = $state.params.containerId ||  $scope.$storage.containerId;
        $scope.$watch('$storage.cluster', function(newValue, oldValue) {
            if (!_.isUndefined(newValue) && !_.isUndefined(oldValue) && newValue._id != oldValue._id) {
                $state.go("service");
            }

        }, true);

        $scope.getDetail = function() {
            if (CommonService.endPointAvailable()) {               
                ContainerService.get(CommonService.getEndPoint(), $scope.containerId,$scope.component.appset_name,$scope.component.name).then(function(data) {            
                        $scope.container = data.data;
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "container.getFailed");
                    })
            }
        };
        $scope.envCondition = !_.isUndefined($scope.component.app.env) && !_.isEmpty($scope.component.app.env);
        $scope.envArray = _.map($scope.component.app.env, function(value, key){
                           var temp = {"key":key,"value":value};
                           return temp; 
                          });
        $scope.condition = !_.isUndefined($scope.component.app.container.volumes) && $scope.component.app.container.volumes>0;
        $scope.restart = function(){
            if (CommonService.endPointAvailable()) {               
                ContainerService.restart(CommonService.getEndPoint(), $scope.containerId,$scope.component.appset_name,$scope.component.name).then(function(data) {            
                        $state.go("service.detail",{"serviceName":$scope.component.appset_name});
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "container.getFailed");
                    })
            }
        };
        $scope.goToMonitoring = function(){
           $sessionStorage.selectedServiceToMonitor = $scope.component.appset_name
           $sessionStorage.selectedContainerToMonitor = $scope.container.name;
           $location.path("/monitor");
        };
        $scope.getDetail();


    }]);




});
