define(['app','directives/pagination', 'services/network/main', 'services/node/main'], function(app) {
	'use strict';
	app.controllerProvider.register('NetworkController', ['$scope', '$sessionStorage', '$uibModal', '$location', '$state', 'NetworkService', 'CommonService', 'ResponseService', function($scope, $sessionStorage, $uibModal, $location, $state, NetworkService, CommonService, ResponseService) {
		$scope.$storage = $sessionStorage;
		$scope.endPointAvailable = CommonService.endPointAvailable();
		$scope.addNetwork = function() {
			if ($scope.endPointAvailable) {
				$uibModal.open({
						templateUrl: 'templates/network/add.html',
						controller: 'AddNetworkController',
						backdrop: 'static',
						resolve: {
							model: function() {
								return {
									users: $scope.users,
									types: $scope.types
								};
							}
						}
					})
					.result
					.then(function(response) {
						if (response.operation === 'execute') {
							NetworkService.createNetwork(CommonService.getEndPoint(), response.data).then(function(data) {
									$scope.getNetwork();
								},
								function(errorMessage) {
									ResponseService.errorResponse(errorMessage);
								});
						}
					});
			}
		};
		$scope.terminateAll = function() {
			$scope.$translate(['common.deleteConfirm', 'network.terminateAllConfirm', 'common.delete']).then(function(translations) {
				$scope.confirm = {
					"title": translations['common.deleteConfirm'],
					"message": translations['network.terminateAllConfirm'],
					"button": {
						"text": translations['common.delete'],
						"action": function() {
							NetworkService.terminateAll(CommonService.getEndPoint(), $scope.$storage.cluster._id).then(function(data) {
								$scope.getNetwork('true');
							}, function(errorMessage) {
								ResponseService.errorResponse(errorMessage);
							})
						}
					}
				};
				CommonService.deleteConfirm($scope);
			});
		};
		$scope.terminateNetwork = function(item,internal) {
			$scope.$translate(['common.deleteConfirm', 'network.terminateConfirm', 'common.delete']).then(function(translations) {
				$scope.confirm = {
					"title": translations['common.deleteConfirm'],
					"message": translations['network.terminateConfirm'],
					"button": {
						"text": translations['common.delete'],
						"action": function() {
							NetworkService.terminateNetwork(CommonService.getEndPoint(), item._id).then(function(data) {
								$scope.getNetwork(internal);
							}, function(errorMessage) {
								ResponseService.errorResponse(errorMessage);
							})
						}
					}
				};
				CommonService.deleteConfirm($scope);
			});
		}
		$scope.getNetwork = function(internal) {
			
			var skip = ($scope.checkdata.currentPage - 1) * $scope.recordPerPage;
			var limit = $scope.recordPerPage;
			if ($scope.endPointAvailable) {
				NetworkService.getNetwork(CommonService.getEndPoint(), skip, limit, $scope.$storage.cluster._id,internal).then(function(data) {
						$scope.network = data.data;
						$scope.totalrecords = data.count;
						$scope.totalPage = Math.ceil($scope.totalrecords / $scope.recordPerPage);
					},
					function(errorMessage) {
						ResponseService.errorResponse(errorMessage);
					});
			}
		};
		$scope.$watch('$storage.cluster', function(nv, ov) {
				if (nv == ov) return;
				$scope.checkdata={
					currentPage:1,
					internal:'true'
				}
				$scope.totalPage = '';
				$scope.totalrecords = '';
				$scope.getNetwork($scope.checkdata.internal);
			}, true);
		$scope.$watch('checkdata', function(nv, ov) {
			$scope.getNetwork($scope.checkdata.internal);
		},true);
		var init = function(internal) {
			$scope.totalPage = '';
			$scope.recordPerPage = CommonService.recordNumPerPage();
			$scope.totalrecords = '';
			$scope.checkdata={
				currentPage:1,
				internal:internal
			}
		};
		init('true');
		$scope.changeInternal=function(internal){
			init(internal);
		}
	}]);
	app.controllerProvider.register('AddNetworkController', ['$scope', '$uibModalInstance', 'model', 'NodeService', '$sessionStorage',
		function($scope, $uibModalInstance, model, NodeService, $sessionStorage) {
			$scope.$storage = $sessionStorage;
			$scope.users = model.users;
			$scope.types = model.types;
			$scope.network = {
				"cluster_id": $scope.$storage.cluster._id,
				"cluster_name": $scope.$storage.cluster.name,
				"user_name": $scope.$storage.cluster.owner,
				"clust_host_name": '',
				"network": {
					"name": "",
					"internal": "false",
					"driver": "overlay",
					"subnet": [],
					"gateway": [],
					"iprange": []
				}
			};
			NodeService.getNodes($scope.network.cluster_id).then(function(data) {
				$scope.network.clust_host_name = _.find(data.data, function(item) {
					return item.issharednode
				}).host_name;
			}, function(errorMessage) {
				ResponseService.errorResponse(errorMessage);
			});
			$scope.close = function(res) {
				$uibModalInstance.close({
					"operation": res,
					"data": $scope.network
				});
			};
		}
	]);
});