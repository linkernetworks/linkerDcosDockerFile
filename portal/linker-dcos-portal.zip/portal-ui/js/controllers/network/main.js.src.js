define(['app', 'services/network/main'], function(app) {
	'use strict';
	app.controllerProvider.register('NetworkController', ['$scope', '$uibModal', '$location', '$state', 'NetworkService','CommonService','ResponseService', function($scope, $uibModal, $location, $state, NetworkService,CommonService,ResponseService) {
		$scope.network = {
			internalNetwork: [{
				segment: '192.168.1.0/24',
				service: 'HSS',
				createdTime: '2016-1-20 12:20:21+8:00'
			}, {
				segment: '192.168.2.0/24',
				service: 'SDmN',
				createdTime: '2016-1-20 12:20:21+8:00'
			}],
			externalNetworkMapping: [{
				externalPort: '10003',
				service: 'HSS',
				createdTime: '2016-1-20 12:20:21+8:00'
			}, {
				externalPort: '10004',
				service: 'SDmN',
				createdTime: '2016-1-20 12:20:21+8:00'
			}]
		}
		NetworkService.getNetwork(CommonService.getEndPoint(), 0, 0).then(function(data) {
				
			},
			function(errorMessage) {
				ResponseService.errorResponse(errorMessage);
			});
	}]);
});