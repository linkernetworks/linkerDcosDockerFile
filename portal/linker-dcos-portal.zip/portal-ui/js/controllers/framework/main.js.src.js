define(['app', 'services/framework/main', 'directives/pagination', 'directives/status'], function(app, FrameworkService) {
    'use strict';
    app.controllerProvider.register('FrameworkController', ['$scope', '$uibModal', '$sessionStorage', '$location', 'FrameworkService', 'CommonService', 'ResponseService', function($scope, $uibModal, $sessionStorage, $location, FrameworkService, CommonService, ResponseService) {

        $scope.$storage = $sessionStorage;

        $scope.recordPerPage = CommonService.recordNumPerPage();
        $scope.currentTaskPage = 1;
        $scope.totalTaskPage = 1;
        $scope.totalTaskRecords = 0;

        $scope.filter = { "taskFilter": "" };
        $scope.endPointAvailable = CommonService.endPointAvailable();
        $scope.$watch('currentTaskPage', function(newValue, oldValue) {
            if (newValue != oldValue) {
                $scope.getTasks();
            }

        });
        // $scope.$watch('filter.taskFilter', function(newValue, oldValue) {
        //     if (newValue != oldValue) {
        //         $scope.currentTaskPage = 1;
        //         $scope.totalTaskPage = 1;
        //         $scope.totalTaskRecords = 0;
        //         $scope.getTasks();
        //     }

        // });

        $scope.$watch('$storage.cluster', function(newValue, oldValue) {
            if (!_.isUndefined(newValue) && !_.isUndefined(oldValue) && newValue._id != oldValue._id) {
                $scope.currentTaskPage = 1;
                $scope.totalTaskPage = 1;
                $scope.totalTaskRecords = 0;
                $scope.endPointAvailable = CommonService.endPointAvailable();
                $scope.getFrameworks();
                $scope.getDeployedFrameworks();
                $scope.getTasks();
            }

        }, true);


        $scope.getFrameworks = function() {
            if ($scope.endPointAvailable) {
                FrameworkService.get(CommonService.getEndPoint(), '', '', 'templates').then(function(data) {
                        $scope.frameworks = data.data;
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "framework.listFailed");
                    })
            } else {
                $scope.frameworks = [];
            }
        };
        // $scope.getData = function() {
        //     $scope.getDeployedFrameworks();
        //     // $scope.getTasks();
        // };
        $scope.getDeployedFrameworks = function() {
            if ($scope.endPointAvailable) {
                FrameworkService.get(CommonService.getEndPoint(), "", "", 'instances').then(function(data) {
                        $scope.deployedFrameworks = data.data;
                        var filterItem = _.find($scope.deployedFrameworks, function(item) {
                                              return item.name == $scope.filter.taskFilter 
                                           });
                        if (_.isUndefined(filterItem)) {
                            $scope.filter.taskFilter = "";
                        } 
                        $scope.currentTaskPage = 1;
                        $scope.totalTaskPage = 0;
                        $scope.totalTaskRecords = 0;
                        $scope.getTasks();
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "framework.listFailed");
                    })
            } else {
                $scope.deployedFrameworks = [];
            }
        };
        $scope.getTasksByFilter = function(){
            $scope.currentTaskPage = 1;
            $scope.totalTaskPage = 0;
            $scope.totalTaskRecords = 0;
            $scope.getTasks();
        };
        $scope.getTasks = function() {
            if ($scope.endPointAvailable) {             
                  var skip = ($scope.currentTaskPage - 1) * $scope.recordPerPage;
                  var limit = $scope.recordPerPage;
                  FrameworkService.get(CommonService.getEndPoint(), skip, limit, 'tasks', $scope.filter.taskFilter).then(function(data) {
                                $scope.totalTaskRecords = data.count;
                                $scope.totalTaskPage = Math.ceil($scope.totalTaskRecords / $scope.recordPerPage);
                                $scope.tasks = data.data;

                   },
                    function(error) {
                        ResponseService.errorResponse(error, "framework.taskListFailed");
                    })
                 
            } else {
                $scope.totalTaskRecords = 0;
                $scope.totalTaskPage = 0;
                $scope.tasks = [];
            }
        };
        $scope.confirmDelete = function(framework, type) {
            $scope.$translate(['common.deleteConfirm', 'framework.uninstallMessage', 'common.uninstall']).then(function(translations) {
                $scope.confirm = {
                    "title": translations['common.deleteConfirm'],
                    "message": translations['framework.uninstallMessage'],
                    "button": {
                        "text": translations['common.uninstall'],
                        "action": function() {
                            $scope.deleteFramework(framework, type);
                        }
                    }

                };
                CommonService.deleteConfirm($scope);
            });
        };
        $scope.deleteFramework = function(framework, type) {
            FrameworkService.delete(CommonService.getEndPoint(), framework, type).then(function(data) {
                    // if (type === "instances") {
                    //     $scope.getDeployedFrameworks();

                    // } else if (type === "templates") {
                    //     $scope.getFrameworks();
                    // }
                    $scope.getFrameworks();

                },
                function(error) {
                    ResponseService.errorResponse(error, "framework.deleteFailed");
                })
        };
        $scope.confirmInstall = function(framework) {
            $scope.$translate(['common.deployConfirm', 'framework.deployMessage', 'common.deploy']).then(function(translations) {
                $scope.confirm = {
                    "title": translations['common.deployConfirm'],
                    "message": translations['framework.deployMessage'],
                    "button": {
                        "text": translations['common.deploy'],
                        "action": function() {
                            $scope.installFramework(framework);
                        }
                    }

                };
                CommonService.deleteConfirm($scope);
            });
        };
        $scope.installFramework = function(framework) {
            var info = { "template_name": framework.name, "name": framework.name };
            FrameworkService.install(CommonService.getEndPoint(), info).then(function(data) {
                    $scope.getFrameworks();
                },
                function(error) {
                    ResponseService.errorResponse(error, "framework.installFailed");
                })
        };




    }]);



});
