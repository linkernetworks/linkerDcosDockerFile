define(['app', 'services/framework/main','directives/pagination','directives/status'], function(app, FrameworkService) {
    'use strict';
    app.controllerProvider.register('FrameworkController', ['$scope', '$sessionStorage', '$location', 'FrameworkService','CommonService', 'ResponseService',function($scope, $sessionStorage, $location, FrameworkService,CommonService,ResponseService) {
        $scope.test = [{ "name": "Spark", "status": "Running", "entrypoint": "http://121.212.33.12:8080", "task": "3","cpu":"2","memory":"2G","duration":"3min" },
            { "name": "Spark", "status": "Running", "entrypoint": "http://121.212.33.12:8080", "task": "3","cpu":"2","memory":"2G","duration":"3min" },
            { "name": "Hadoop", "status": "Running", "entrypoint": "http://121.212.33.12:8080", "task": "3","cpu":"2","memory":"2G","duration":"3min" }
        ];
        $scope.tasks = [{ "id": "spark.21140502-d6ee-11e5-a6f7-02424ffe4192", "status": "Running", "name": "spark", "host": "host-1", "starttime": "2016-1-20 12:20:21+8:00", "endtime": "2016-1-20 12:20:21+8:00", "period": "2min1sec" },
            { "id": "spark.21140502-d6ee-11e5-a6f7-02424ffe4192", "status": "Running", "name": "spark", "host": "host-1", "starttime": "2016-1-20 12:20:21+8:00", "endtime": "2016-1-20 12:20:21+8:00", "period": "2min1sec" },
            { "id": "spark.21140502-d6ee-11e5-a6f7-02424ffe4192", "status": "Running", "name": "spark", "host": "host-1", "starttime": "2016-1-20 12:20:21+8:00", "endtime": "2016-1-20 12:20:21+8:00", "period": "2min1sec" }
        ];
        $scope.$storage = $sessionStorage;

        $scope.recordPerPage = CommonService.recordNumPerPage();
        $scope.currentTaskPage = 1;
        $scope.currentDeployedFrameworkPage = 1;
        $scope.totalTaskPage = 1;
        $scope.totalDeployedFrameworkPage = 1;
        $scope.totalTaskRecords = 0;
        $scope.totalDeployedFramworkRecords = 0;
        $scope.taskFilter="all";

        $scope.$watch('currentTaskPage', function(newValue,oldValue) {
            if (newValue != oldValue) {
            	$scope.getTasks();
            }					
            
        });
        $scope.$watch('currentDeployedFrameworkPage', function(newValue,oldValue) {
            if (newValue != oldValue) {
            	$scope.getDeployedFrameworks();
            }	
            
        });

        $scope.$watch('$storage.cluster', function(newValue,oldValue) {
			if(!_.isUndefined(newValue) && !_.isUndefined(oldValue) && newValue._id != oldValue._id){
				$scope.getFrameworks();
				$scope.getDeployedFrameworks();
				$scope.getTasks();
			}
			
		},true);

	
        $scope.getFrameworks = function() {
            if (CommonService.endPointAvailable()) {
                FrameworkService.getFrameworks(CommonService.getEndPoint()).then(function(data) {
                        $scope.frameworks = data.data;
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "framework.listFailed");
                    })
            }else{
                $scope.frameworks = [];
            }
        };
        $scope.getDeployedFrameworks = function() {
            if (CommonService.endPointAvailable()) {
            	var skip = ($scope.currentDeployedFrameworkPage - 1) * $scope.recordPerPage;
				var limit = $scope.recordPerPage;
                FrameworkService.getDeployedFrameworks(CommonService.getEndPoint(), skip, limit).then(function(data) {                 
                        $scope.totalDeployedFramworkRecords = data.count;
					    $scope.totalDeployedFrameworkPage = Math.ceil($scope.totalDeployedFramworkRecords / $scope.recordPerPage);
					    $scope.deployedFrameworks = data.data;
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "framework.listFailed");
                    })
            }else{
                $scope.totalDeployedFramworkRecords = 0;
                $scope.totalDeployedFrameworkPage = 0;
                $scope.deployedFrameworks = [];
            }
        };
        $scope.getTasks = function() {
            if (CommonService.endPointAvailable()) {
            	var skip = ($scope.currentTaskPage - 1) * $scope.recordPerPage;
				var limit = $scope.recordPerPage;
                FrameworkService.getTasks(CommonService.getEndPoint(),skip, limit, $scope.taskFilter).then(function(data) {
                        $scope.totalTaskRecords = data.count;
					    $scope.totalTaskPage = Math.ceil($scope.totalTaskRecords / $scope.recordPerPage);
                        $scope.tasks = data.data;
                    },
                    function(error) {
                        ResponseService.errorResponse(error, "framework.listFailed");
                    })
            }else{
                  $scope.totalTaskRecords = 0;
                  $scope.totalTaskPage = 0;
                  $scope.tasks = [];
            }
        };
        $scope.confirmDelete = function(framework, type) {
            $scope.$translate(['common.deleteConfirm', 'framework.uninstallMessage', 'common.uninstall']).then(function(translations) {
                $scope.confirm = {
                    "title": translations['common.deleteConfirm'],
                    "message": translations['framework.uninstallMessage'],
                    "button": {
                        "text": translations['common.uninstall'],
                        "action": function() {
                            $scope.uninstallFramework(framework,type);
                        }
                    }

                };
                CommonService.deleteConfirm($scope);
            });
        };
        $scope.uninstallFramework = function(framework,type) {
            FrameworkService.uninstallFramework(framework).then(function(data) {
                    if(type === "deployed"){
                    	$scope.getDeployedFrameworks();

                    }else{
                    	$scope.getFrameworks();
                    }
                    
                },
                function(error) {
                    ResponseService.errorResponse(error, "framework.uninstallFailed");
                })
        };
         $scope.confirmInstall = function(framework) {
            $scope.$translate(['common.deployConfirm', 'framework.deployMessage', 'common.deploy']).then(function(translations) {
                $scope.confirm = {
                    "title": translations['common.deployConfirm'],
                    "message": translations['framework.deployMessage'],
                    "button": {
                        "text": translations['common.deploy'],
                        "action": function() {
                            $scope.installFramework(framework);
                        }
                    }

                };
                CommonService.deleteConfirm($scope);
            });
        };
        $scope.installFramework = function(framework) {
            FrameworkService.installFramework(framework).then(function(data) {               
                    	$scope.getFrameworks();                    
                },
                function(error) {
                    ResponseService.errorResponse(error, "framework.uninstallFailed");
                })
        };


















    }]);



});
