define(['app','services/node/main'], function(app) {
	'use strict';
	app
		.controllerProvider
		.register('NodeDetailController', ['$scope','CommonService', 'NodeService',function($scope,CommonService,NodeService) {
			$scope.cluster = {
				name: '用户集群节点-1',
				type: 'AWS',
				cpus: '8',
				ip: '192.168.10.172',
				memory: '16GB',
				status: '空闲',
				createTime: '2016-1-20 12:20:21+8:00',
				keypair: 'Jay Zhou',
				clusterid:'aaaaaaaaaaaaaaaa',
				nodeid:'bbbbbbbbbbbb',
				containers: [{
					name: 'DCOS.mesos-slave',
					service: 'DCOS系统服务',
					image: '-',
					vers: '-',
					status: '正常',
					createTime: '2016-1-20 12:20:21+8:00',
					updateTime: '2016-1-20 12:20:21+8:00'
				}, {
					name: 'liuliang.mysql',
					service: '流量平台',
					image: 'docker.io/mysql',
					vers: '5.6',
					status: '正常',
					createTime: '2016-1-20 12:20:21+8:00',
					updateTime: '2016-1-20 12:20:21+8:00'
				}, {
					name: 'liuliang.tomcat3',
					service: '流量平台',
					image: 'docker.io',
					vers: '4.8',
					status: '正常',
					createTime: '2016-1-20 12:20:21+8:00',
					updateTime: '2016-1-20 12:20:21+8:00'
				}, {
					name: 'mifi-server.mysql2',
					service: 'MIFI服务',
					image: 'docker.io',
					vers: '5.2',
					status: '正常',
					createTime: '2016-1-20 12:20:21+8:00',
					updateTime: '2016-1-20 12:20:21+8:00'
				}],
				framework: [{
					id: 'spark.21140502-d6ee-11e5-a6f7-02424ffe4192',
					name: 'spark',
					startTime: '2016-1-20 12:20:21+8:00',
					endTime: '2016-1-20 12:20:21+8:00',
					continue: '2分12秒',
					status: 'finish'
				}, {
					id: 'spark.21140502-d6ee-11e5-a6f7-02424ffe4192',
					name: 'spark',
					startTime: '2016-1-20 12:20:21+8:00',
					endTime: '2016-1-20 12:20:21+8:00',
					continue: '2分12秒',
					status: 'finish'
				}, {
					id: 'spark.21140502-d6ee-11e5-a6f7-02424ffe4192',
					name: 'spark',
					startTime: '2016-1-20 12:20:21+8:00',
					endTime: '2016-1-20 12:20:21+8:00',
					continue: '2分12秒',
					status: 'finish'
				}, {
					id: 'spark.21140502-d6ee-11e5-a6f7-02424ffe4192',
					name: '	hadoop1',
					startTime: '2016-1-20 12:20:21+8:00',
					endTime: '2016-1-20 12:20:21+8:00',
					continue: '2分12秒',
					status: 'failed'
				}, {
					id: 'spark.21140502-d6ee-11e5-a6f7-02424ffe4192',
					name: '	hadoop1',
					startTime: '2016-1-20 12:20:21+8:00',
					endTime: '2016-1-20 12:20:21+8:00',
					continue: '2分12秒',
					status: 'finish'
				}, {
					id: 'spark.21140502-d6ee-11e5-a6f7-02424ffe4192',
					name: '	hadoop1',
					startTime: '2016-1-20 12:20:21+8:00',
					endTime: '2016-1-20 12:20:21+8:00',
					continue: '2分12秒',
					status: 'finish'
				}]
			}
			$scope.confirmDelete = function() {
				$scope.$translate(['common.deleteConfirm', 'node.uninstallMessage', 'common.uninstall']).then(function(translations) {
					$scope.confirm = {
						"title": translations['common.deleteConfirm'],
						"message": translations['node.uninstallMessage'],
						"button": {
							"text": translations['common.uninstall'],
							"action": function() {
								$scope.deleteNode();
							}
						}

					};
					CommonService.deleteConfirm($scope);
				});
			};
			$scope.deleteNode=function(){
				NodeService.terminateNode($scope.cluster);
			}
		}]);
});