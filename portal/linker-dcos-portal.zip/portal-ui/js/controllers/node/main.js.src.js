define(['app', 'services/node/main', 'services/cluster/main', 'directives/pagination', 'directives/status'], function(app) {
	'use strict';
	app
		.controllerProvider
		.register('NodeController', ['$scope','$state', '$sessionStorage', '$stateParams', '$location', '$uibModal', 'NodeService', 'ResponseService', 'CommonService', 'ClusterService', function($scope,$state,$sessionStorage, $stateParams, $location, $uibModal, NodeService, ResponseService, CommonService, ClusterService) {
			$scope.$storage = $sessionStorage;
			$scope.nodedetail=function(detail){
				$scope.$storage.node=detail;
				$state.go("nodedetail",{nodeid:detail.HostId});
			};
			$scope.refreshCluster=function(){
				ClusterService.getCluster($scope.$storage.cluster._id).then(function(data){
					if($scope.$storage.cluster.status==data.data.status){
						$scope.getNode()
					}else{
						$scope.$storage.cluster.status = data.data.status;
						$scope.$parent.selectCluster=JSON.stringify($scope.$storage.cluster);
						_.find($scope.$parent.clusters,function(item){
							if(item._id==$scope.$storage.cluster._id){
								item.status=$scope.$storage.cluster.status
							}
						})
					}
				},function(errorMessage){
					ResponseService.errorResponse(errorMessage);
				})
			}
			$scope.getNode = function() {
				if (CommonService.clusterAvailable()) {
					var skip = ($scope.currentPage - 1) * $scope.recordPerPage;
					var limit = $scope.recordPerPage;
					NodeService.getNodes($scope.$storage.cluster._id, skip, limit).then(function(data) {
						$scope.totalrecords = data.count;
						$scope.totalPage = Math.ceil($scope.totalrecords / $scope.recordPerPage);
						$scope.node = data.data;
					}, function(errorMessage) {
						ResponseService.errorResponse(errorMessage);
					});
				}else{
					$scope.node=[];
					$scope.totalrecords = 0;
					$scope.totalPage = Math.ceil($scope.totalrecords / $scope.recordPerPage);
				}
			};
			$scope.selectAll = function(checked) {
				_.each($scope.node, function(item) {
					if (!item.ismasternode && !item.issharednode && (item.status != 'TERMINATING') && (item.status != 'INSTALLING')) {
						item.select = checked;
					}
				})
			};
			$scope.$watch('node', function(nv, ov) {
				if (nv == ov) return;
				if(!$scope.node){
					$scope.nodeSelectAll = false;
					return
				}
				if ($scope.node.length) {
					$scope.nodeSelectAll = _.every($scope.node, function(item) {
						if (!item.ismasternode && !item.issharednode && (item.status != 'TERMINATING') && (item.status != 'INSTALLING')) {
							if (item.select == true) {
								return true
							} else {
								return false
							}
						} else {
							return true
						}
					}) && !_.every($scope.node, function(item) {
						if (!item.ismasternode && !item.issharednode && (item.status != 'TERMINATING') && (item.status != 'INSTALLING')) {
							return false
						} else {
							return true
						}
					});
				} else {
					$scope.nodeSelectAll = false;
				}
			}, true);
			$scope.addNode = function() {
				$uibModal.open({
						templateUrl: 'templates/node/addNode.html',
						controller: 'createNodeController',
						backdrop: 'static',
						resolve: {
							model: function() {
								return {

								};
							}
						}
					})
					.result
					.then(function(response) {
						if (response.operation === 'execute') {
							_.each(response.data.label, function(item) {
								response.data.nodeattribute += item.key + ':' + item.value + ';';
							});
							if (!_.isUndefined(response.data.addnode.privatekey)) {
								response.data.addnode.privatekey = Base64.encode(response.data.addnode.privatekey);
							}
							response.data.label = null;
							if (response.data.addmode == 'reuse' || $scope.$storage.cluster.type == 'customized') {
								response.data.addnumber = response.data.addnode.nodes.length;
							}
							NodeService.createNode(response.data).then(function() {
								$scope.refreshCluster();
							}, function(errorMessage) {
								ResponseService.errorResponse(errorMessage);
							})
						}
					});
			};
			$scope.terminateNode = function(item) {
				var node = {
					_id: [item.HostId],
					cluster_id: item.cluster_id
				}
				$scope.$translate(['common.deleteConfirm', 'node.deleteNodeMessage', 'common.delete']).then(function(translations) {
					$scope.confirm = {
						"title": translations['common.deleteConfirm'],
						"message": translations['node.deleteNodeMessage'],
						"button": {
							"text": translations['common.delete'],
							"action": function() {
								NodeService.terminateNode(node).then(function() {
									$scope.refreshCluster();
								}, function(errorMessage) {
									ResponseService.errorResponse(errorMessage);
								});
							}
						}

					};
					CommonService.deleteConfirm($scope);
				});
			};
			$scope.terminateNodes = function() {
				$scope.$translate(['common.deleteConfirm', 'node.deleteNodesMessage', 'common.delete']).then(function(translations) {
					$scope.confirm = {
						"title": translations['common.deleteConfirm'],
						"message": translations['node.deleteNodesMessage'],
						"button": {
							"text": translations['common.delete'],
							"action": function() {
												var nodes = {
					_id: [],
					cluster_id: $scope.$storage.cluster._id
				}
				nodes._id = _.chain($scope.node).filter(function(item) {
					if (!item.ismasternode && !item.issharednode && (item.status != 'TERMINATING') && (item.status != 'INSTALLING')) {
						if (item.select == true) {
							return true
						} else {
							return false
						}
					} else {
						return false
					}
				}).map(function(item) {
					return item.HostId
				}).value();
				if (nodes._id.length) {
					NodeService.terminateNode(nodes).then(function() {
						$scope.refreshCluster();
					}, function(errorMessage) {
						ResponseService.errorResponse(errorMessage);
					});
				} else {
					$uibModal.open({
						templateUrl: 'templates/common/ConfirmAbsort.html',
						controller: 'ConfirmAbsortController',
						backdrop: 'static',
						resolve: {
							model: function() {
								return {
									message: {
										"title": "common.NoChoice",
										"content": "common.PleaseSelectTheCorrespondingNode",
										"button": "common.confirm"
									}
								};
							}
						}
					});
				}
							}
						}

					};
					CommonService.deleteConfirm($scope);
				});
			}
			var init = function() {
				//得到选择的id
				$scope.currentPage = 1;
				$scope.totalPage = 1;
				$scope.recordPerPage = CommonService.recordNumPerPage();
				$scope.totalrecords = 0;
				$scope.$watch('$storage.cluster', function() {
					$scope.currentPage = 1;  
                 	$scope.totalPage = 1;       
                 	$scope.totalRecords = 0;       
					$scope.getNode();
				}, true);
				$scope.$watch('currentPage', function(nv, ov) {
					if (nv == ov) return;
					$scope.getNode();
				});

			};
			init();
		}]);
	app.controllerProvider.register('ConfirmAbsortController', ['$scope', '$uibModalInstance', 'model',
		function($scope, $uibModalInstance, model) {
			$scope.message = model.message;
			$scope.close = function(res) {
				$uibModalInstance.close({
					"operation": res
				});
			};
		}
	]);
	app.controllerProvider.register('createNodeController', ['$scope', '$sessionStorage', '$uibModalInstance', 'model',
		function($scope, $sessionStorage, $uibModalInstance, model) {
			$scope.$storage = $sessionStorage;
			var init = function() {
				if ($scope.$storage.cluster.type != 'customized') {
					$scope.node = {
						addmode: "new",
						addnumber: 1,
						clusterId: $scope.$storage.cluster._id,
						nodeattribute: "",
						label: [{}],
						addnode: {
							privatekey: "",
							nodes: [{
								ip: "",
								sshuser: ""
							}]
						}
					};
					$scope.$watch('node.addmode', function(nv, ov) {
						if (nv == ov) return;
						if (nv == "new") {
							$scope.node.label = [{}];
						} else {
							$scope.node.label = [];
							$scope.node.addnode = {
								privatekey: "",
								nodes: [{
									ip: "",
									sshuser: ""
								}]
							};
						}
						$scope.node.addnumber = 1;
					});
				} else {
					$scope.node = {
						addmode: "new",
						addnumber: 1,
						clusterId: $scope.$storage.cluster._id,
						nodeattribute: "",
						label: [{}],
						addnode: {
							privatekey: "",
							nodes: [{
								ip: "",
								sshuser: ""
							}]
						}
					};
				}
			}
			$scope.pushLabel = function() {
				$scope.node.label.push({});
			};
			$scope.popLabel = function(index) {
				$scope.node.label.splice(index,1);
			};
			$scope.popNode = function(index) {
				$scope.node.addnode.nodes.splice(index,1);
			};
			$scope.pushNode = function() {
				$scope.node.addnode.nodes.push({});
			};
			init();

			$scope.close = function(res) {
				$uibModalInstance.close({
					"operation": res,
					"data": $scope.node
				});
			};
		}
	]);

});