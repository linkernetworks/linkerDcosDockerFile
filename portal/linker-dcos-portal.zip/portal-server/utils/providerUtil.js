'use strict';

require('sugar');
var controllerHA = global.obj.dcosCfg.controllerProvider.ha;
var identityHA = global.obj.dcosCfg.identityProvider.ha;

var ProviderUtil = function (providerType) {
  this.providerType = providerType ? providerType : "controllerProvider";
};

ProviderUtil.prototype.rebuildUrl = function(path){
	return "http://" + path;
};
ProviderUtil.prototype.parseProviderUrl = function(req,res,next){    
    var self = this;
       
        if(controllerHA.enabled){
            global.obj.zkUtil_controller.getProviderUrl();        
		}else{
		    global.obj.controller_url = controllerHA.controller_url;
		}

    	if(identityHA.enabled){
            global.obj.zkUtil_identity.getProviderUrl();        
		}else{
		    global.obj.identity_url = identityHA.identity_url;
		}
		    
    return next();
};

module.exports = ProviderUtil;
