'use strict';
var request = require('request');

var logger = global.obj.logger;
var urlCfg = global.obj.urlCfg;

var Authentication = require('../utils/authentication');

var providerUtil = require('../utils/providerUtil');
var ProviderUtil = new providerUtil("controllerProvider");
var ResponseError = require('../utils/responseUtil').model;

module.exports = function(app) {
	//	新建集群
	app.post('/cluster', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster),
			method: 'POST',
			json: true,
			body: req.body,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error creating cluster :', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Created cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to create cluster by request" + options.url);
		request(options, callback);
	});

	//发送邮箱
	app.post('/cluster/:clusterid/email', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + req.params.clusterid + '/email'),
			method: 'POST',
			json: true,
			body: req.body,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error creating cluster :', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Created cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to create cluster by request" + options.url);
		request(options, callback);
	});

	//	查询集群
	app.get('/cluster', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + '?sort=-time_update&status=unterminated&count=' + req.query.count + '&skip=' + req.query.skip + '&limit=' + req.query.limit + '&user_id=' + req.query.user_id),
			method: 'GET',
			json: true,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error querying cluster :', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Queryed cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to query cluster by request" + options.url);
		request(options, callback);
	});

	//删除单个集群
	app.delete('/cluster', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster),
			method: 'DELETE',
			json: true,
			body: req.body,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error deleteing cluster:', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Deleted cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to delete cluster by request " + options.url);
		request(options, callback);
	});

	//增加节点
	app.post('/cluster/:clusterid/hosts', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + req.params.clusterid + '/hosts?number='+req.query.number),
			method: 'POST',
			json: true,
			body: req.body,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error creating cluster :', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Created cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to create cluster by request" + options.url);
		request(options, callback);
	});

	//删除节点
	app.delete('/cluster/:clusterid/hosts', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + req.params.clusterid + '/hosts'),
			method: 'DELETE',
			json:true,
			body: req.body,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error deleteing cluster:', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Deleted cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to delete cluster by request " + options.url);
		request(options, callback);
	});
	//查询节点
	app.get('/cluster/:clusterid/hosts', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + req.params.clusterid + '/hosts?sort=-time_update&status=unterminated&count='+ req.query.count + '&skip=' + req.query.skip + '&limit=' + req.query.limit),
			method: 'GET',
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error querying cluster:', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Queryed cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to query node by request " + options.url);
		request(options, callback);
	});


}