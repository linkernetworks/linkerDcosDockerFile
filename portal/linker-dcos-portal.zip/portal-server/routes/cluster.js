'use strict';
// var request = require('request');

var logger = global.obj.logger;
var urlCfg = global.obj.urlCfg;

var Authentication = require('../utils/authentication');

var providerUtil = require('../utils/providerUtil');
var ProviderUtil = new providerUtil("controllerProvider");
var request = ProviderUtil.request;

var ResponseError = require('../utils/responseUtil').model;

module.exports = function(app) {
	//	create cluster
	app.post('/cluster', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		req.body.user_id=req.session.userid;
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster),
			method: 'POST',
			json: true,
			body: req.body,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var a=JSON.stringify(req.body);
		logger.trace("JSON" + req.body);
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error creating cluster :', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Created cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to create cluster by request" + options.url);
		request(options, callback);
	});

	//send email
	app.post('/cluster/:clusterid/email', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + req.params.clusterid + '/email'),
			method: 'POST',
			json: true,
			body: req.body,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error creating cluster :', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Created cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to create cluster by request" + options.url);
		request(options, callback);
	});

	//	list cluster
	app.get('/cluster', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var userid = req.query.user_id || req.session.userid;
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + '?sort=-time_update&status='+req.query.status+'&count=' + req.query.count + '&skip=' + req.query.skip + '&limit=' + req.query.limit + '&user_id=' + userid),
			method: 'GET',
			json: true,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error querying cluster :', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Queryed cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to query cluster by request" + options.url);
		request(options, callback);
	});
	//query cluster
	app.get('/cluster/:clusterid', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + req.params.clusterid),
			method: 'GET',
			json: true,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error querying cluster :', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Queryed cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to query cluster by request" + options.url);
		request(options, callback);
	});

	// delete single cluster
	app.delete('/cluster/:clusterid', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster+req.params.clusterid),
			method: 'DELETE',
			json: true,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error deleteing cluster:', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Deleted cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to delete cluster by request " + options.url);
		request(options, callback);
	});

	// add node
	app.post('/cluster/:clusterid/hosts', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + req.params.clusterid + '/hosts'),
			method: 'POST',
			json: true,
			body: req.body,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error creating cluster :', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Created cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to create cluster by request" + options.url);
		request(options, callback);
	});

	//delete node
	app.delete('/cluster/:clusterid/hosts', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + req.params.clusterid + '/hosts'),
			method: 'DELETE',
			json:true,
			body: req.body,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error deleteing cluster:', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Deleted cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to delete cluster by request " + options.url);
		request(options, callback);
	});
	//list node
	app.get('/cluster/:clusterid/hosts', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.cluster + req.params.clusterid + '/hosts?sort=-time_update&status=unterminated&count='+ req.query.count + '&skip=' + req.query.skip + '&limit=' + req.query.limit),
			method: 'GET',
			json:true,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error querying cluster:', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Queryed cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to query node by request " + options.url);
		request(options, callback);
	});
    // validate whether cluster name is duplicate for user
	app.get('/cluster/validate/duplicate', Authentication.ensureAuthenticated, ProviderUtil.parseProviderUrl, function(req, res, next) {
		var options = {
			url: ProviderUtil.rebuildUrl(global.obj.controller_url + urlCfg.controller_api.validateCluster + '?clustername='+ req.query.clustername + '&userid=' + req.session.userid),
			method: 'GET',
			json:true,
			headers: {
				'X-Auth-Token': req.session.token
			}
		};
		var callback = function(error, response, body) {
			if (error || response.statusCode >= 400) {
				logger.error('Error validate cluster name:', error ? error.errno : response.statusCode, body);
				next(new ResponseError(error, response, body));
			} else {
				logger.trace('Validate cluster', body);
				res.status(200).send(body);
			}
		};
		logger.trace("Start to validate cluster name " + options.url);
		request(options, callback);
	});


}