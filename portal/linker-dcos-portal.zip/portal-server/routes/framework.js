'use strict';
// var request = require('request');

var urlCfg = global.obj.urlCfg;
var linkerConf = global.obj.dcosCfg;

var logger = require('../utils/logger');

var Authentication = require('../utils/authentication');

var providerUtil = require('../utils/providerUtil');

var ProviderUtil = new providerUtil("dcosClientProvider");
var request = ProviderUtil.request;

var ResponseError = require('../utils/responseUtil').model;

module.exports = function (app) {
    app.get('/frameworks/:type', Authentication.ensureAuthenticated,function(req, res, next) {
        var tempURL = req.query.clientAddr + urlCfg.dcosclient_api.framework +'/'+req.params.type + '?sort=-time_update&count=' + req.query.count + '&skip=' + req.query.skip + '&limit=' + req.query.limit;
        var url = req.params.type == "tasks" ? tempURL + "&framework_name="+req.query.framework_name : tempURL;
        var options = {
          url: ProviderUtil.rebuildUrl(url),
          method: 'GET',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error get framework list:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get framework list', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    
    app.delete('/frameworks/:type/:name', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.framework+"/"+req.params.type+"/"+req.params.name),
          method: 'DELETE',
          json:true,       
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error delete framework:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Delete framework:', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    // create framework instance in db, if deploy is true then send the request to mesos to deploy template
    app.post('/frameworks/instances', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.framework+"/instances?deploy="+req.query.deploy),
          method: 'POST',
          json:true,  
          body: req.body,     
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error install framework:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Install framework:', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    // deploy framework instance by mesos
    app.put('/frameworks/instances/:name/deploy', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.framework+"/instances/"+req.params.name+"/deploy"),
          method: 'PUT',
          json:true,    
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error deploy framework instance:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Deploy framework instance:', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
 
    app.get('/tasks', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.framework +'/tasks?sort=-time_update&count=' + req.query.count + '&skip=' + req.query.skip + '&limit=' + req.query.limit + '&host_ip=' + req.query.host_ip),
          method: 'GET',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error get framework tasks list:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get framework tasks list', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    
};