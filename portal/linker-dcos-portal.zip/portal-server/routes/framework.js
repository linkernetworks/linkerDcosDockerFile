'use strict';
// var request = require('request');

var urlCfg = global.obj.urlCfg;
var linkerConf = global.obj.dcosCfg;

var logger = require('../utils/logger');

var Authentication = require('../utils/authentication');

var providerUtil = require('../utils/providerUtil');

var ProviderUtil = new providerUtil("dcosClientProvider");
var request = ProviderUtil.request;

var ResponseError = require('../utils/responseUtil').model;

module.exports = function (app) {
    app.get('/frameworks/deployed', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.framework + '?sort=-time_update&count=' + req.query.count + '&skip=' + req.query.skip + '&limit=' + req.query.limit),
          method: 'GET',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error get deployed framework list:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get deployed framework list', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.get('/frameworks/task', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.framework + '?sort=-time_update&count=' + req.query.count + '&skip=' + req.query.skip + '&limit=' + req.query.limit),
          method: 'GET',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error get task list:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get task list', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.get('/frameworks', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.framework),
          method: 'GET',
          json:true,       
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error get framework list:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get framework list', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.delete('/frameworks/:id', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.framework+"/"+req.params.id),
          method: 'DELETE',
          json:true,       
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error uninstall framework:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Uninstall framework:', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
     app.post('/frameworks', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.framework+"/"+req.query.name),
          method: 'POST',
          json:true,       
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error install framework:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Install framework:', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });

    
};