'use strict';
// var request = require('request');

var urlCfg = global.obj.urlCfg;
var linkerConf = global.obj.dcosCfg;

var logger = require('../utils/logger');

var Authentication = require('../utils/authentication');

var providerUtil = require('../utils/providerUtil');

var ProviderUtil = new providerUtil("dcosClientProvider");
var request = ProviderUtil.request;

var ResponseError = require('../utils/responseUtil').model;

module.exports = function (app) {
    app.get('/appsets', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.appset + '?sort=-time_create&count=' + req.query.count + '&skip=' + req.query.skip + '&limit=' + req.query.limit+'&skip_group='+req.query.skip_group),
          method: 'GET',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error get service list:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get service list', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.get('/appsets/:name', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.appset + '/' + req.params.name),
          method: 'GET',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error get service detail:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get service detail', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.post('/appsets', Authentication.ensureAuthenticated, function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.appset),
          method: 'POST',
          json:true,
          body: req.body,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error save appset list:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get appset list', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.put('/appsets/:name/stop', Authentication.ensureAuthenticated, function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.appset + "/" + req.params.name + "/stop"),
          method: 'PUT',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error stop appset:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Stop appset', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.put('/appsets/:name/start', Authentication.ensureAuthenticated, function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.appset + "/" + req.params.name + "/restart"),
          method: 'PUT',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error start appset:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Start appset', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.delete('/appsets/:name', Authentication.ensureAuthenticated, function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.appset + "/" + req.params.name),
          method: 'DELETE',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error delete appset:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Delete appset', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.get('/component', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.component + '?name=' + req.query.name+"&appset_name="+req.query.appset_name),
          method: 'GET',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error get component detail:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get component detail', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.post('/component', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.component),
          method: 'POST',
          json:true,
          body: req.body,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var a = JSON.stringify(req.body);
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error save component:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Save component', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.put('/component', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.component+"/"+req.body._id+"?appset_name="+req.body.appset_name),
          method: 'PUT',
          json:true,
          body: req.body,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        // var a = JSON.stringify(req.body);
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error save component:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Save component', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.put('/component/scale', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.component + "/scale?name=" + req.query.name + "&appset_name="+req.query.appset_name+"&scaleto="+req.query.scaleto),
          method: 'PUT',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error scale component:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Scale component', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.put('/component/start', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.component + "/start?name=" + req.query.name + "&appset_name="+req.query.appset_name),
          method: 'PUT',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error start component:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Start component', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.put('/component/stop', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.component + "/stop?name=" + req.query.name + "&appset_name="+req.query.appset_name),
          method: 'PUT',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error stop component:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Stop component', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
    });
    app.delete('/component', Authentication.ensureAuthenticated, function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.component + "?name=" + req.query.name + "&appset_name="+req.query.appset_name),
          method: 'DELETE',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error delete component:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Delete component', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
  });
  app.get('/container/:id', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.container + '/' + req.params.id+"?appset_name="+req.query.appset_name+"&component_name="+req.query.component_name),
          method: 'GET',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error get container detail:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Get container detail', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
  });
   app.put('/container/:id/restart', Authentication.ensureAuthenticated,function(req, res, next) {
        var options = {
          url: ProviderUtil.rebuildUrl(req.query.clientAddr + urlCfg.dcosclient_api.container + '/' + req.params.id+"/restart?appset_name="+req.query.appset_name+"&component_name="+req.query.component_name),
          method: 'PUT',
          json:true,
          headers: {
             'X-Auth-Token': req.session.token
          }
        };
        var callback = function(error, response, body) {
          if(error || response.statusCode >= 400){
               logger.error('Error restart container:', error ? error.errno : response.statusCode, body);
               next(new ResponseError(error, response, body));
          }else{
               logger.trace('Restart container', body);
               res.status(200).send(body);
          }
        };      
        request(options, callback);
  });


    
};